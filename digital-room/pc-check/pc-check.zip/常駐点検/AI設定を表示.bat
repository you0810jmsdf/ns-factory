@echo off
rem Shows the MCP config to paste into an AI app (Claude Desktop / Claude Code / Codex / Gemini CLI / Cursor ...).
rem Read-only: this only prints text. Nothing is changed or sent.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0proc_check_mcp.ps1" -ShowConfig
echo.
pause
