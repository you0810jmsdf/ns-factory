@echo off
rem Launcher: opens the PC check page (double-click, Start menu or desktop shortcut).
rem The server runs hidden (no window to close by mistake) and ends 10 minutes after the page is closed.
start "ProcCheck" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0proc_check.ps1" -Serve -Open
