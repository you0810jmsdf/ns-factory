﻿<#
  proc_check_mcp.ps1   常駐点検を AI アプリにつなぐ MCP サーバー（PowerShell 5.1 ／ 日本語を含むので UTF-8 BOM 付きで保存すること）

  何をするか
    MCP（Model Context Protocol）に対応した AI アプリ（Claude Desktop・Claude Code・Codex・Gemini CLI・Cursor など）から、
    常駐点検の結果を読めるようにする。標準入出力（stdio）の JSON-RPC。
    道具は読み取り専用の 2 つ（止める道具は出さない。止めるのは常駐点検のページの停止ボタンだけ）：
      pc_check           … いまの PC の重さを調べる（診断・赤の警告・主なプログラムの一覧）
      pc_process_detail  … pc_check が返した id から、プログラム 1 件の詳しい情報

  使い方
    proc_check_mcp.ps1 -ShowConfig   … AI アプリに書き込む設定を、このファイルの実際の場所で表示する（これを貼る）
    proc_check_mcp.ps1               … AI アプリが起動する（手で起動するものではない。起動すると入力待ちになる）

  外へ出るもの
    このスクリプト自身は何も送らない。AI アプリが道具を呼び、その結果を本人の AI に渡す（渡すかどうかは AI アプリの設定と本人の許可）。
    鍵やパスワードは *** に、ユーザー名は〈ユーザー〉に置き換えて返す。
#>
[CmdletBinding()]
param(
  [switch]$ShowConfig,
  [int]$SampleSeconds = 5,
  [switch]$NoDns
)

Set-StrictMode -Off
$ErrorActionPreference = 'Continue'
$script:Root = $PSScriptRoot
if (-not $script:Root) { $script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path }
$script:Main = Join-Path $script:Root 'proc_check.ps1'
$script:Self = Join-Path $script:Root 'proc_check_mcp.ps1'
$script:Version = '1.0'
$script:Last = $null
$script:Utf8 = New-Object System.Text.UTF8Encoding($false)

# ============================================================
#  -ShowConfig：AI アプリに貼る設定を、実際の場所で表示する
# ============================================================
if ($ShowConfig) {
  try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
  $p = $script:Self
  $pj = $p -replace '\\', '\\'
  Write-Host ''
  Write-Host '=== 1. JSON で設定する AI アプリ（Claude Desktop・Gemini CLI・Cursor など）：設定ファイルの "mcpServers" に足す ==='
  Write-Host '{'
  Write-Host '  "mcpServers": {'
  Write-Host '    "pc-check": {'
  Write-Host '      "command": "powershell.exe",'
  Write-Host ('      "args": ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", "' + $pj + '"]')
  Write-Host '    }'
  Write-Host '  }'
  Write-Host '}'
  Write-Host ''
  Write-Host '=== 2. Claude Code（コマンド 1 行。PowerShell から打つときは claude.cmd と書く。claude だと -- が消えて失敗する） ==='
  Write-Host ('claude.cmd mcp add --scope user pc-check -- powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $p + '"')
  Write-Host ''
  Write-Host '=== 3. Codex CLI（~/.codex/config.toml に追記） ==='
  Write-Host '[mcp_servers.pc-check]'
  Write-Host 'command = "powershell.exe"'
  Write-Host ('args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", "' + $pj + '"]')
  Write-Host ''
  Write-Host '設定ファイルの場所（例）：Claude Desktop は %APPDATA%\Claude\claude_desktop_config.json ／ Gemini CLI は ~/.gemini/settings.json ／ Cursor は .cursor/mcp.json'
  Write-Host '登録したら AI アプリを再起動し、「PC が重い。pc_check で調べて」と頼んでみてください。'
  exit 0
}

# ============================================================
#  小さな道具
# ============================================================
function Mask-User([string]$s) {
  # C:\Users\名前 ・ /mnt/c/Users/名前 ・ /home/名前 の「名前」と、ログイン名そのものを伏せる
  if (-not $s) { return $s }
  $s = [regex]::Replace($s, '([A-Za-z]:\\Users\\|/mnt/[a-z]/Users/|/home/)([^\\/"''\s]+)', '$1〈ユーザー〉', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  $u = [string]$env:USERNAME
  if ($u.Length -ge 4) { $s = [regex]::Replace($s, [regex]::Escape($u), '〈ユーザー〉', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) }
  return $s
}

function Format-Age([double]$sec) {
  if ($sec -lt 90) { return ('{0}秒' -f [int]$sec) }
  if ($sec -lt 5400) { return ('{0}分' -f [int]($sec / 60)) }
  if ($sec -lt 172800) { return ('{0}時間{1}分' -f [int][Math]::Floor($sec / 3600), [int](($sec % 3600) / 60)) }
  return ('{0}日{1}時間' -f [int][Math]::Floor($sec / 86400), [int](($sec % 86400) / 3600))
}

function Get-Prop($obj, [string]$name) {
  if ($null -eq $obj) { return $null }
  $pp = $obj.PSObject.Properties[$name]
  if ($pp) { return $pp.Value } else { return $null }
}

function ConvertTo-ReadableJson($obj) {
  # ConvertTo-Json は日本語を \uXXXX にする。AI が読みやすいよう、ASCII 以外の文字だけ元に戻す（JSON としての意味は同じ）。
  # 「\\u3042」（エスケープ済みの \ のあとに u3042）を誤って戻さないよう、\\ を先に拾う。
  $json = ConvertTo-Json -InputObject $obj -Depth 30
  $ev = [System.Text.RegularExpressions.MatchEvaluator]{
    param($m)
    if (-not $m.Groups[1].Success) { return $m.Value }
    $cp = [Convert]::ToInt32($m.Groups[1].Value, 16)
    if ($cp -ge 0x80 -and -not ($cp -ge 0xD800 -and $cp -le 0xDFFF)) { return [string][char]$cp }
    return $m.Value
  }
  return [regex]::Replace($json, '\\\\|\\u([0-9a-fA-F]{4})', $ev)
}

# ============================================================
#  常駐点検を呼ぶ（同じフォルダの proc_check.ps1 -Json を、この PowerShell の中で実行）
# ============================================================
function Invoke-Check([int]$sec) {
  if (-not (Test-Path -LiteralPath $script:Main)) { throw ('proc_check.ps1 が見つかりません: ' + $script:Main) }
  $a = @{ Json = $true; SampleSeconds = $sec }      # ハッシュで渡す（配列だと位置引数になって -Json が Port に入る）
  if ($NoDns) { $a.NoDns = $true }
  # 画面向けの表示（Write-Host など）は標準出力に混ぜない（MCP の通信路を汚さないため）
  $raw = & $script:Main @a 6>$null 5>$null 4>$null 3>$null 2>$null
  $txt = (@($raw) | ForEach-Object { [string]$_ }) -join ''
  $i = $txt.IndexOf('{'); $j = $txt.LastIndexOf('}')
  if ($i -lt 0 -or $j -le $i) { throw '常駐点検の結果（JSON）を受け取れませんでした。' }
  $d = ConvertFrom-Json -InputObject $txt.Substring($i, $j - $i + 1)
  $script:Last = $d
  return $d
}

function ConvertTo-Color([string]$level) {
  switch ($level) { 'ok' { return '緑（快適）' } 'warn' { return '黄（少し負担）' } 'bad' { return '赤（重くなっている原因あり）' } default { return $level } }
}

function ConvertTo-ProgramRow($r, [bool]$withCmd) {
  $flags = @(Get-Prop $r 'flags')
  $named = [bool](Get-Prop $r 'named')
  $o = [ordered]@{
    id = [string]$r.gid; 所属 = [string]$r.所属; 名札 = [string]$r.名札; 想定 = [string]$r.想定
    'CPU%' = $r.cpu; メモリMB = $r.memMB; 起動から = (Format-Age ([double]$r.ageSec)); 外部接続 = $r.ext
    警告 = $flags; 説明 = [string]$r.説明; 助言 = [string]$r.助言
  }
  $sub = [string](Get-Prop $r 'sub'); if ($sub) { $o.補足 = (Mask-User $sub) }
  $cmd = [string](Get-Prop $r 'cmd')
  if ($cmd -and ($withCmd -or (-not $named) -or $flags.Count -gt 0)) {
    $c = Mask-User $cmd; if ($c.Length -gt 240) { $c = $c.Substring(0, 240) + '…' }
    $o.コマンド行 = $c
  }
  $hosts = @(Get-Prop $r 'hosts')
  if ($hosts.Count -gt 0 -and ($withCmd -or $flags.Count -gt 0)) {
    $o.接続先 = @($hosts | Select-Object -First 4 | ForEach-Object { if ($_.host) { [string]$_.host } else { [string]$_.ip } })
  }
  return $o
}

function ConvertTo-Summary($d, [bool]$full) {
  $rows = @(Get-Prop $d 'rows')
  if ($full) { $list = $rows }
  else {
    $pick = [ordered]@{}
    foreach ($r in @($rows | Where-Object { @(Get-Prop $_ 'flags').Count -gt 0 })) { $pick[[string]$r.gid] = $r }
    foreach ($r in @($rows | Sort-Object { -[double]$_.cpu } | Where-Object { [double]$_.cpu -ge 1 } | Select-Object -First 10)) { $pick[[string]$r.gid] = $r }
    foreach ($r in @($rows | Sort-Object { -[double]$_.memMB } | Select-Object -First 10)) { $pick[[string]$r.gid] = $r }
    $list = @($pick.Values | Select-Object -First 25)
  }
  $progs = @(foreach ($r in $list) { ConvertTo-ProgramRow $r $false })
  $dg = $d.diagnosis; $sys = $d.system
  $sevWord = @{ 2 = '要対応'; 1 = '注意'; 0 = 'ヒント' }
  $causes = @(); $n = 0
  foreach ($f in @(Get-Prop $dg 'findings')) {
    $n++
    $causes += [ordered]@{ 順位 = $n; 重さ = [string]$sevWord[[int]$f.sev]; 題 = [string]$f.title; どういうこと = (Mask-User ([string]$f.why)); どうすればいい = (Mask-User ([string]$f.todo)); 関係するid = @(Get-Prop $f 'gids') }
  }
  $warns = @(foreach ($w in @(Get-Prop $d 'warnings')) { [ordered]@{ 種別 = [string]$w.kind; 名札 = [string]$w.title; 理由 = (Mask-User ([string]$w.reason)); 助言 = [string]$w.advice; id = [string]$w.gid } })
  $hid = Get-Prop $d 'hidden'
  return [ordered]@{
    計測 = [string]$d.generatedText; 観測秒 = $d.sampleSeconds; CPU本数 = $d.cpus
    全体 = [ordered]@{ 'CPU%' = $sys.cpuPct; 'メモリ%' = $sys.memPct; メモリ使用MB = $sys.memUsedMB; メモリ総MB = $sys.memTotalMB; 'ディスク忙しさ%' = $sys.diskBusy; ドライブ = $sys.drive; 空きGB = $sys.freeGB; 起動からの日数 = $sys.uptimeDays }
    診断 = [ordered]@{ 色 = (ConvertTo-Color ([string]$dg.level)); 見出し = [string]$dg.headline; 要点 = [string]$dg.lead; 原因 = $causes }
    赤の警告 = $warns
    プログラム = $progs
    プログラムの件数 = [ordered]@{ 返した = $progs.Count; 全体 = $rows.Count; 返し方 = $(if ($full) { '全部' } else { '警告のあるものと、CPU・メモリの上位（最大25件）。全部は full=true' }) }
    目立たない小さなプログラム = [ordered]@{ 個数 = (Get-Prop $hid 'count'); 'CPU%' = (Get-Prop $hid 'cpu'); メモリMB = (Get-Prop $hid 'memMB') }
    注意 = '鍵やパスワードは *** に、ユーザー名は〈ユーザー〉に置き換えてあります。この道具は調べるだけで、何も止めていません。止める操作は、常駐点検のページ（常駐点検.bat）の停止ボタンだけです。'
  }
}

function Find-Row([string]$gid) {
  if ($script:Last) { $r = @(Get-Prop $script:Last 'rows') | Where-Object { [string]$_.gid -eq $gid } | Select-Object -First 1; if ($r) { return $r } }
  $null = Invoke-Check 2
  return (@(Get-Prop $script:Last 'rows') | Where-Object { [string]$_.gid -eq $gid } | Select-Object -First 1)
}

function ConvertTo-Detail($r) {
  $o = ConvertTo-ProgramRow $r $true
  $o.'最大CPU%' = $r.maxCpu
  $o.'ディスクMB/秒' = $r.ioMBs
  $o.番号PID = @(Get-Prop $r 'pids')
  $o.親のたどり順 = @(Get-Prop $r 'chain')
  $exe = [string](Get-Prop $r 'exe'); if ($exe) { $o.実行ファイル = (Mask-User $exe) }
  $mk = [string](Get-Prop $r 'maker'); if ($mk) { $o.作成元 = $mk }
  $o.接続先の詳細 = @(foreach ($h in @(Get-Prop $r 'hosts')) { [ordered]@{ 相手 = $(if ($h.host) { [string]$h.host } else { [string]$h.ip }); IP = [string]$h.ip; 判定 = $(if ($h.known) { '許可リスト内（' + [string]$h.rule + '）' } else { '許可リストにない' }); 件数 = $h.n } })
  $o.停止の可否 = [string]$r.停止
  $o.台帳の目安 = (Get-Prop $r '目安')
  $o.注意 = 'この道具からは止められません。止めるなら常駐点検のページの停止ボタン（2回押し）を案内し、保存していない作業を先に保存するよう伝えてください。'
  return $o
}

# ============================================================
#  MCP（JSON-RPC over stdio）
# ============================================================
$script:Instructions = @'
常駐点検（じょうちゅうてんけん）：Windows PC の「重い原因」を調べる、読み取り専用の道具です。
- まず pc_check を呼んでください。診断の色（緑＝快適／黄＝少し負担／赤＝原因あり）、原因の一覧（どういうこと・どうすればいい）、赤の警告、主なプログラムが返ります。
- 「名札」は台帳で付けた日本語名です。「名前の分からないプログラム（xxx.exe）」は台帳にないものです。正体や止めてよいかは、pc_process_detail のコマンド行・親のたどり順・作成元・接続先を手がかりに、専門用語を使わずに説明してください。分からないことは「分からない」と言ってください。
- 赤の警告の種別：空回り（仕事をせず CPU を使い続ける）／置き去り（作業中だけのはずが残っている）／目安超え（台帳の目安を超えた）／未知の接続（許可リストにない相手）。
- この道具から止めることはできません。止めるなら、常駐点検のページ（常駐点検.bat をダブルクリック）の停止ボタンを案内し、保存していない作業を先に保存するよう伝えてください。
- 鍵やパスワードは *** に、ユーザー名は〈ユーザー〉に置き換えてあります。
'@

$script:Tools = @(
  [ordered]@{
    name = 'pc_check'
    title = 'PC が重い原因を調べる'
    description = 'いまの PC の重さの原因を調べる（約5秒の観測）。診断（緑/黄/赤・原因・対処）、赤の警告、主なプログラム（名札・CPU・メモリ・起動からの時間・外部接続）を返す。読み取りだけで、何も止めない。'
    inputSchema = [ordered]@{
      type = 'object'
      properties = [ordered]@{
        sample_seconds = [ordered]@{ type = 'integer'; minimum = 2; maximum = 15; description = '観測する秒数（既定 5）' }
        full = [ordered]@{ type = 'boolean'; description = 'true で全プログラム行を返す（既定は、警告のあるものと CPU・メモリの上位 25 件）' }
      }
      additionalProperties = $false
    }
    annotations = [ordered]@{ readOnlyHint = $true; destructiveHint = $false; idempotentHint = $true; openWorldHint = $false }
  },
  [ordered]@{
    name = 'pc_process_detail'
    title = 'プログラム 1 件の詳しい情報'
    description = 'pc_check が返した id（例 g1234_1699999999）のプログラム 1 件の詳しい情報：コマンド行（鍵は伏せ字）、親のたどり順、外部の接続先と判定、番号(PID)、作成元、台帳の説明と助言。'
    inputSchema = [ordered]@{
      type = 'object'
      properties = [ordered]@{ id = [ordered]@{ type = 'string'; description = 'pc_check の結果にある id' } }
      required = @('id')
      additionalProperties = $false
    }
    annotations = [ordered]@{ readOnlyHint = $true; destructiveHint = $false; idempotentHint = $true; openWorldHint = $false }
  }
)

$script:In = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $script:Utf8)
$script:Out = New-Object System.IO.StreamWriter([Console]::OpenStandardOutput(), $script:Utf8)
$script:Out.AutoFlush = $true
$script:Err = New-Object System.IO.StreamWriter([Console]::OpenStandardError(), $script:Utf8)   # 記録は標準エラー（AI アプリのログに残る）
$script:Err.AutoFlush = $true

function Write-Message($obj) {
  $json = ConvertTo-Json -InputObject $obj -Depth 30 -Compress
  $script:Out.Write($json + "`n")
  $script:Out.Flush()
}
function Send-Result($id, $result) { Write-Message ([ordered]@{ jsonrpc = '2.0'; id = $id; result = $result }) }
function Send-Error($id, [int]$code, [string]$message) { Write-Message ([ordered]@{ jsonrpc = '2.0'; id = $id; error = [ordered]@{ code = $code; message = $message } }) }
function New-ToolResult([string]$text, [bool]$isError) { return [ordered]@{ content = @([ordered]@{ type = 'text'; text = $text }); isError = $isError } }
function Write-Log([string]$s) { try { $script:Err.WriteLine('[pc-check] ' + $s) } catch { } }

Write-Log ('start pid=' + $PID + ' root=' + $script:Root)
while ($true) {
  $line = $script:In.ReadLine()
  if ($null -eq $line) { break }                      # AI アプリが入力を閉じた → 終了
  if ($line.Trim().Length -eq 0) { continue }
  $msg = $null
  try { $msg = ConvertFrom-Json -InputObject $line } catch { Send-Error $null -32700 'Parse error'; continue }
  $hasId = ($msg.PSObject.Properties.Name -contains 'id')
  $id = $(if ($hasId) { $msg.id } else { $null })
  $method = [string](Get-Prop $msg 'method')
  $params = Get-Prop $msg 'params'
  try {
    if ($method -eq 'initialize') {
      $pv = [string](Get-Prop $params 'protocolVersion')
      if ($pv -notin @('2024-11-05', '2025-03-26', '2025-06-18')) { $pv = '2025-06-18' }
      Send-Result $id ([ordered]@{
        protocolVersion = $pv
        capabilities = [ordered]@{ tools = [ordered]@{ listChanged = $false } }
        serverInfo = [ordered]@{ name = 'pc-check'; title = '常駐点検（PC が重い原因を調べる）'; version = $script:Version }
        instructions = $script:Instructions
      })
    }
    elseif ($method -like 'notifications/*') { }       # 通知には返事をしない
    elseif ($method -eq 'ping') { Send-Result $id ([ordered]@{}) }
    elseif ($method -eq 'tools/list') { Send-Result $id ([ordered]@{ tools = $script:Tools }) }
    elseif ($method -eq 'tools/call') {
      $name = [string](Get-Prop $params 'name')
      $args2 = Get-Prop $params 'arguments'
      if ($name -eq 'pc_check') {
        $sec = $SampleSeconds
        $v = Get-Prop $args2 'sample_seconds'; if ($v) { $sec = [int]$v }
        if ($sec -lt 2) { $sec = 2 }; if ($sec -gt 15) { $sec = 15 }
        $full = [bool](Get-Prop $args2 'full')
        $d = Invoke-Check $sec
        Send-Result $id (New-ToolResult (ConvertTo-ReadableJson (ConvertTo-Summary $d $full)) $false)
      }
      elseif ($name -eq 'pc_process_detail') {
        $gid = [string](Get-Prop $args2 'id')
        if (-not $gid) { Send-Result $id (New-ToolResult 'id を指定してください（pc_check の結果にある id）。' $true) }
        else {
          $r = Find-Row $gid
          if (-not $r) { Send-Result $id (New-ToolResult ('id ' + $gid + ' のプログラムは見つかりません。終了したか、id が古い可能性があります。pc_check をもう一度呼んでください。') $true) }
          else { Send-Result $id (New-ToolResult (ConvertTo-ReadableJson (ConvertTo-Detail $r)) $false) }
        }
      }
      else { Send-Error $id -32602 ('Unknown tool: ' + $name) }
    }
    elseif ($hasId) { Send-Error $id -32601 ('Method not found: ' + $method) }
  } catch {
    Write-Log ('error: ' + $_.Exception.Message)
    if ($hasId) { Send-Error $id -32603 ('Internal error: ' + $_.Exception.Message) }
  }
}
Write-Log 'end'
exit 0
