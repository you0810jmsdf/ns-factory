﻿<#
  常駐点検  proc_check.ps1   （PowerShell 5.1 ／ 日本語を含むので UTF-8 BOM 付きで保存すること）

  使い方（くわしくは README.md）
    常駐点検.bat をダブルクリック        … ページを開く（-Serve -Open と同じ）
    proc_check.ps1 -Serve [-Open]        … 127.0.0.1:18790 だけで待ち受けるページを起動（ページを閉じて10分で自分で終わる）
    proc_check.ps1 -Report [-Mail]       … 常駐点検.html を書いて終了（-Mail は赤の警告があるときだけメール）
  テスト用: -SpinMinutes 0 / -LeftoverHours 0（しきい値を0にする）  -LedgerOnly <json>（そのJSONだけを台帳にする）
            -NoNet（接続の点検を省く）  -NoDns（逆引きをしない）  -SampleSeconds <秒>
  このスクリプトは情報を集めて表示するだけです。外部へ送るのは -Mail のときの警告メール1通だけ（設定がある場合のみ）。
#>
[CmdletBinding()]
param(
  [switch]$Serve, [switch]$Report, [switch]$Mail, [switch]$TestMail, [switch]$Open,
  [int]$Port = 18790,
  [double]$IdleMinutes = 10,
  [double]$SpinMinutes = -1,
  [double]$LeftoverHours = -1,
  [int]$SampleSeconds = 5,
  [switch]$NoNet, [switch]$NoDns,
  [string]$LedgerOnly = '',
  [string]$OutHtml = '',
  [switch]$Json
)

Set-StrictMode -Off
$ErrorActionPreference = 'Continue'
$script:Root = $PSScriptRoot
if (-not $script:Root) { $script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path }
$script:Cpus = 0
[void][int]::TryParse([string]$env:NUMBER_OF_PROCESSORS, [ref]$script:Cpus)
if ($script:Cpus -lt 1) { $script:Cpus = [Environment]::ProcessorCount }
$script:DnsCache = @{}
$script:SpinState = @{}
$script:MakerCache = @{}
$script:LastData = $null
$script:LastGroups = @{}
$script:ProtectedNames = '^(System|Registry|Idle|smss|csrss|wininit|winlogon|services|lsass|lsaiso|svchost|dwm|fontdrvhost|explorer|MsMpEng|MemCompression|Memory Compression|vmcompute|vmmem|sihost)$'

# ============================================================
#  1. 小さな道具（IP・CIDR・JSON）
# ============================================================
function Read-JsonFile([string]$path) {
  if (-not $path -or -not (Test-Path -LiteralPath $path)) { return $null }
  try { return (Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json) }
  catch { Write-Host ("台帳が読めません: " + $path + " : " + $_.Exception.Message); return $null }
}

function ConvertTo-IpBytes([string]$s) {
  if (-not $s) { return $null }
  $s = $s.Split('%')[0]
  $ip = $null
  if (-not [System.Net.IPAddress]::TryParse($s, [ref]$ip)) { return $null }
  try { if ($ip.IsIPv6 -and $ip.IsIPv4MappedToIPv6) { $ip = $ip.MapToIPv4() } } catch { }
  return , $ip.GetAddressBytes()
}

function Test-InternalIp([byte[]]$b) {
  if ($b.Length -eq 4) {
    $a = [int]$b[0]; $c = [int]$b[1]
    return ($a -eq 10 -or $a -eq 127 -or $a -eq 0 -or ($a -eq 169 -and $c -eq 254) -or ($a -eq 172 -and $c -ge 16 -and $c -le 31) -or ($a -eq 192 -and $c -eq 168) -or ($a -eq 100 -and $c -ge 64 -and $c -le 127) -or $a -ge 224)
  }
  $allZeroHead = $true
  for ($i = 0; $i -lt 15; $i++) { if ($b[$i] -ne 0) { $allZeroHead = $false; break } }
  if ($allZeroHead -and ($b[15] -le 1)) { return $true }
  if ($b[0] -eq 0xfe -and (($b[1] -band 0xc0) -eq 0x80)) { return $true }
  if (($b[0] -band 0xfe) -eq 0xfc) { return $true }
  if ($b[0] -eq 0xff) { return $true }
  return $false
}

function New-Cidr([string]$s) {
  $p = $s.Split('/')
  $b = ConvertTo-IpBytes $p[0]
  if (-not $b) { return $null }
  return [pscustomobject]@{ Bytes = $b; Bits = [int]$p[1] }
}

function Test-Cidr([byte[]]$bytes, $c) {
  if ($bytes.Length -ne $c.Bytes.Length) { return $false }
  $bits = $c.Bits; $i = 0
  while ($bits -ge 8) { if ($bytes[$i] -ne $c.Bytes[$i]) { return $false }; $i++; $bits -= 8 }
  if ($bits -gt 0) {
    $mask = (0xFF -shl (8 - $bits)) -band 0xFF
    if (($bytes[$i] -band $mask) -ne ($c.Bytes[$i] -band $mask)) { return $false }
  }
  return $true
}

function ConvertTo-SafeJson($obj, [int]$depth = 12) {
  $j = ConvertTo-Json -InputObject $obj -Depth $depth -Compress
  $j = $j.Replace('<', '\u003c').Replace('>', '\u003e').Replace([string][char]0x2028, '\u2028').Replace([string][char]0x2029, '\u2029')
  return $j
}

# ============================================================
#  2. 台帳（標準 ＋ 自分用）
# ============================================================
function Import-Ledger {
  $std = $null; $own = $null
  if ($LedgerOnly) { $own = Read-JsonFile $LedgerOnly }
  else {
    $std = Read-JsonFile (Join-Path $script:Root '常駐台帳_標準.json')
    $own = Read-JsonFile (Join-Path $script:Root '常駐台帳.json')
  }
  $settings = @{ '空回り分' = 10.0; '置き去り時間' = 6.0; '未知接続を警告にする' = $false; 'セッション題名の場所' = '' }
  foreach ($src in @($std, $own)) {
    if ($src -and $src.設定) { foreach ($pr in $src.設定.PSObject.Properties) { $settings[$pr.Name] = $pr.Value } }
  }
  $entries = New-Object System.Collections.ArrayList
  foreach ($src in @($own, $std)) {
    if (-not $src) { continue }
    foreach ($e in @($src.名札)) {
      if (-not $e -or -not $e.プロセス名) { continue }
      try {
        $nrx = [regex]::new('^(?:' + $e.プロセス名 + ')$', 'IgnoreCase')
        $crx = $null
        if ($e.コマンド行) { $crx = [regex]::new([string]$e.コマンド行, 'IgnoreCase') }
        $e | Add-Member -NotePropertyName _nrx -NotePropertyValue $nrx -Force
        $e | Add-Member -NotePropertyName _crx -NotePropertyValue $crx -Force
        [void]$entries.Add($e)
      } catch { Write-Host ("台帳の正規表現が不正: " + $e.id) }
    }
  }
  $rules = New-Object System.Collections.ArrayList
  foreach ($src in @($own, $std)) {
    if (-not $src) { continue }
    foreach ($r in @($src.許可相手)) {
      if (-not $r -or -not $r.名前) { continue }
      $hrx = $null
      if ($r.ホスト) { try { $hrx = [regex]::new([string]$r.ホスト, 'IgnoreCase') } catch { } }
      $cidrs = @(); foreach ($c in @($r.CIDR)) { if ($c) { $cc = New-Cidr ([string]$c); if ($cc) { $cidrs += $cc } } }
      [void]$rules.Add([pscustomobject]@{ Name = [string]$r.名前; Scope = [string]$r.範囲; HostRx = $hrx; Cidrs = $cidrs })
    }
  }
  $script:Ledger = @{ Entries = @($entries); Rules = @($rules); Settings = $settings; HasOwn = [bool]$own }
}

function Find-Entry([string]$nameNoExt, [string]$cmd) {
  foreach ($e in $script:Ledger.Entries) {
    if (-not $e._nrx.IsMatch($nameNoExt)) { continue }
    if ($e._crx) { if (-not $cmd -or -not $e._crx.IsMatch($cmd)) { continue } }
    return $e
  }
  return $null
}

# ============================================================
#  3. 集める（プロセス・全体の様子・接続）
# ============================================================
function Get-Snapshot {
  $t0 = [DateTime]::UtcNow
  $list = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)
  $t1 = [DateTime]::UtcNow
  $mid = $t0.AddTicks([long](($t1 - $t0).Ticks / 2))
  $h = @{}
  foreach ($p in $list) {
    $procId = [int]$p.ProcessId
    if ($procId -eq 0 -or -not $p.CreationDate) { continue }   # System Idle は開始時刻がなく、数えない
    $h[$procId] = @{
      pid = $procId; ppid = [int]$p.ParentProcessId; name = [string]$p.Name; cmd = [string]$p.CommandLine; exe = [string]$p.ExecutablePath
      start = $p.CreationDate; ws = [double]$p.WorkingSetSize
      cpuSec = ([double]$p.UserModeTime + [double]$p.KernelModeTime) / 1e7
      io = [double]$p.ReadTransferCount + [double]$p.WriteTransferCount
    }
  }
  return @{ Time = $mid; Procs = $h }
}

function Get-DiskBusy {
  try {
    $d = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'" -ErrorAction Stop
    return [Math]::Min(100.0, [double]$d.PercentDiskTime)
  } catch { return $null }
}

function Get-SystemInfo($diskSamples) {
  $o = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  $totalMB = 0; $freeMB = 0; $uptimeDays = 0; $osName = ''
  if ($o) {
    $totalMB = [double]$o.TotalVisibleMemorySize / 1024; $freeMB = [double]$o.FreePhysicalMemory / 1024
    $uptimeDays = ((Get-Date) - $o.LastBootUpTime).TotalDays; $osName = [string]$o.Caption
  }
  $drive = $env:SystemDrive; if (-not $drive) { $drive = 'C:' }
  $ld = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $drive + "'") -ErrorAction SilentlyContinue
  $freeGB = $null; $totalGB = $null
  if ($ld -and $ld.Size) { $freeGB = [double]$ld.FreeSpace / 1GB; $totalGB = [double]$ld.Size / 1GB }
  $disk = $null
  if ($diskSamples -and @($diskSamples).Count -gt 0) { $disk = (@($diskSamples) | Measure-Object -Average).Average }
  return @{
    memTotalMB = [Math]::Round($totalMB); memUsedMB = [Math]::Round($totalMB - $freeMB)
    memPct = $(if ($totalMB -gt 0) { [Math]::Round(($totalMB - $freeMB) / $totalMB * 100, 1) } else { 0 })
    uptimeDays = [Math]::Round($uptimeDays, 1); os = $osName; drive = $drive
    freeGB = $(if ($freeGB -ne $null) { [Math]::Round($freeGB, 1) } else { $null })
    totalGB = $(if ($totalGB -ne $null) { [Math]::Round($totalGB, 1) } else { $null })
    diskBusy = $(if ($disk -ne $null) { [Math]::Round($disk, 0) } else { $null })
  }
}

function Get-ExternalConnections {
  # pid -> @{ ip -> 件数 }   （確立済みTCPのうち、プライベート/ループバック/Tailscale(100.64/10)以外）
  $map = @{}
  try {
    $conns = @(Get-NetTCPConnection -State Established -ErrorAction Stop)
  } catch { return $map }
  foreach ($c in $conns) {
    $ra = [string]$c.RemoteAddress
    $b = ConvertTo-IpBytes $ra
    if (-not $b) { continue }
    if (Test-InternalIp $b) { continue }
    $procId = [int]$c.OwningProcess
    $ipKey = $ra.Split('%')[0]
    if (-not $map.ContainsKey($procId)) { $map[$procId] = @{} }
    if ($map[$procId].ContainsKey($ipKey)) { $map[$procId][$ipKey]++ } else { $map[$procId][$ipKey] = 1 }
  }
  return $map
}

function Resolve-HostNames($ips) {
  # [System.Net.Dns]::GetHostEntry の逆引きを、並列・全体で2秒まで待つ。無理なら IP のまま。
  $now = Get-Date
  $todo = @()
  foreach ($ip in $ips) {
    if ($script:DnsCache.ContainsKey($ip) -and ($now - $script:DnsCache[$ip].at).TotalMinutes -lt 30) { continue }
    $todo += $ip
  }
  if ($NoDns -or $todo.Count -eq 0) {
    foreach ($ip in $todo) { $script:DnsCache[$ip] = @{ host = ''; at = $now } }
    return
  }
  $tasks = @{}
  foreach ($ip in $todo) { try { $tasks[$ip] = [System.Net.Dns]::GetHostEntryAsync($ip) } catch { $tasks[$ip] = $null } }
  $arr = @(); foreach ($t in $tasks.Values) { if ($t) { $arr += $t } }
  if ($arr.Count -gt 0) { try { [void][System.Threading.Tasks.Task]::WaitAll([System.Threading.Tasks.Task[]]$arr, 2000) } catch { } }
  foreach ($ip in $todo) {
    $hn = ''
    $t = $tasks[$ip]
    if ($t -and $t.IsCompleted -and -not $t.IsFaulted -and -not $t.IsCanceled) { try { $hn = [string]$t.Result.HostName; if ($hn -eq $ip) { $hn = '' } } catch { } }
    $script:DnsCache[$ip] = @{ host = $hn; at = $now }
  }
}

function Get-IpVerdict([string]$ip, $entry) {
  $b = ConvertTo-IpBytes $ip
  $hn = ''
  if ($script:DnsCache.ContainsKey($ip)) { $hn = [string]$script:DnsCache[$ip].host }
  $extra = @()
  if ($entry -and $entry.許可相手) { $extra = @($entry.許可相手) }
  foreach ($r in $script:Ledger.Rules) {
    if ($r.Scope -eq '個別' -and ($extra -notcontains $r.Name)) { continue }
    if ($b) { foreach ($c in $r.Cidrs) { if (Test-Cidr $b $c) { return @{ known = $true; rule = $r.Name; host = $hn } } } }
    if ($hn -and $r.HostRx -and $r.HostRx.IsMatch($hn)) { return @{ known = $true; rule = $r.Name; host = $hn } }
  }
  return @{ known = $false; rule = ''; host = $hn }
}

function Get-Maker([string]$exe) {
  if (-not $exe) { return '' }
  if ($script:MakerCache.ContainsKey($exe)) { return $script:MakerCache[$exe] }
  $m = ''
  try { $m = [string](Get-Item -LiteralPath $exe -ErrorAction Stop).VersionInfo.CompanyName } catch { }
  $script:MakerCache[$exe] = $m
  return $m
}

function Get-SessionTitle([string]$sid) {
  $dir = [string]$script:Ledger.Settings['セッション題名の場所']
  if (-not $dir -or -not $sid) { return '' }
  try {
    $p = Join-Path (Join-Path $script:Root $dir) ($sid + '.json')
    if (Test-Path -LiteralPath $p) { $j = Read-JsonFile $p; if ($j -and $j.title) { return [string]$j.title } }
  } catch { }
  return ''
}

# ============================================================
#  4. 名札を付けて束ねる・判定する
# ============================================================
function Get-ParentProc($procs, $p) {
  $q = $procs[[int]$p.ppid]
  if ($q -and $q.start -le $p.start) { return $q }
  return $null
}

function Get-GroupKey($procs, $entryOf, $gkey, $p) {
  if ($gkey.ContainsKey($p.pid)) { return $gkey[$p.pid] }
  $e = $entryOf[$p.pid]
  $key = $null
  if ($e -and $e.束ね -eq '全部') { $key = 'e:' + $e.id }
  else {
    $par = Get-ParentProc $procs $p
    $same = $false
    if ($par) {
      $pe = $entryOf[$par.pid]
      if ($e -and $pe -and $pe.id -eq $e.id) {
        $same = ($e.束ね -eq '親子') -or (($par.name -eq $p.name) -and ($par.cmd -eq $p.cmd)) -or ($par.name -match '^py\.exe$')
      } elseif (-not $e -and -not $pe) {
        $same = ($par.name -eq $p.name) -and ($par.cmd -eq $p.cmd)
      }
    }
    if ($same) { $key = Get-GroupKey $procs $entryOf $gkey $par } else { $key = 'p:' + $p.pid }
  }
  $gkey[$p.pid] = $key
  return $key
}

function Get-SpinMinutes($p, [double]$cpu, [double]$avg, [double]$ageSec, [DateTime]$now) {
  $thr = 70.0 / $script:Cpus   # 「1コア相当」＝1コアの7割（PCが混んでいると、全力で回る1スレッドでも7〜10割しか測れないため）
  $key = [string]$p.pid + '|' + $p.start.Ticks
  if ($cpu -lt $thr) { if ($script:SpinState.ContainsKey($key)) { $script:SpinState.Remove($key) }; return 0.0 }
  $est = 0.0
  if ($avg -ge $thr) { $est = $ageSec / 60.0 }            # 起動からずっと1コア以上 ＝ 起動してからの全時間
  $st = $script:SpinState[$key]
  if (-not $st -or ($now - $st.last).TotalMinutes -gt 3) { $st = @{ since = $now; last = $now } }
  $st.last = $now; $script:SpinState[$key] = $st
  $obs = ($now - $st.since).TotalMinutes                    # このサーバーが続けて見ている時間
  return [Math]::Max($est, $obs)
}

function Hide-Secrets([string]$s) {
  # コマンド行に鍵・パスワードが入っていても、画面・記録（常駐点検.html）に出さない
  if (-not $s) { return $s }
  $s = [regex]::Replace($s, '(?i)(token|secret|passw(?:or)?d|pwd|api[-_ ]?key|apikey|authorization|bearer|client[-_]?secret|access[-_]?key)(["''\s:=]+)([^\s"'',;]{4,})', '$1$2***')
  $s = [regex]::Replace($s, '\b[A-Za-z0-9_\-]{40,}\b', '***')
  return $s
}

function Get-StopLevel($entry, $rootName) {
  if ($rootName -match $script:ProtectedNames) { return '不可' }
  if ($entry -and $entry.停止) { return [string]$entry.停止 }
  return '確認'
}

function Format-Age([double]$sec) {
  if ($sec -lt 90) { return ('{0}秒' -f [int]$sec) }
  if ($sec -lt 5400) { return ('{0}分' -f [int]($sec / 60)) }
  if ($sec -lt 172800) { return ('{0}時間{1}分' -f [int][Math]::Floor($sec / 3600), [int](($sec % 3600) / 60)) }
  return ('{0}日{1}時間' -f [int][Math]::Floor($sec / 86400), [int](($sec % 86400) / 3600))
}

# ============================================================
#  5. 全体を集めて、グループにして、赤の警告を決める
# ============================================================
function Invoke-Collect {
  $now = Get-Date
  $spinMin = $(if ($SpinMinutes -ge 0) { $SpinMinutes } else { [double]$script:Ledger.Settings['空回り分'] })
  $leftHrs = $(if ($LeftoverHours -ge 0) { $LeftoverHours } else { [double]$script:Ledger.Settings['置き去り時間'] })
  $netWarn = [bool]$script:Ledger.Settings['未知接続を警告にする']

  # --- 5秒の観測 ---
  $s1 = Get-Snapshot
  $disk = @()
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while ($sw.Elapsed.TotalSeconds -lt $SampleSeconds) {
    $left = $SampleSeconds - $sw.Elapsed.TotalSeconds
    Start-Sleep -Milliseconds ([int][Math]::Min(1000, [Math]::Max(100, $left * 1000)))
    $v = Get-DiskBusy; if ($v -ne $null) { $disk += $v }
  }
  $s2 = Get-Snapshot
  $now = Get-Date
  $elapsed = [Math]::Max(0.5, ($s2.Time - $s1.Time).TotalSeconds)
  $procs = $s2.Procs
  $sys = Get-SystemInfo $disk

  # --- 接続 ---
  $netByPid = @{}
  if (-not $NoNet) {
    $netByPid = Get-ExternalConnections
    $ips = @{}
    foreach ($k in $netByPid.Keys) { foreach ($ip in $netByPid[$k].Keys) { $ips[$ip] = 1 } }
    Resolve-HostNames @($ips.Keys)
  }

  # --- プロセスごとの数値 ---
  $perf = @{}
  $totalBusy = 0.0
  foreach ($procId in $procs.Keys) {
    $p = $procs[$procId]
    $ageSec = [Math]::Max(1.0, ($now - $p.start).TotalSeconds)
    $p1 = $s1.Procs[$procId]
    if ($p1 -and $p1.start -eq $p.start) {
      $cpu = [Math]::Max(0.0, ($p.cpuSec - $p1.cpuSec) / $elapsed / $script:Cpus * 100.0)
      $io = [Math]::Max(0.0, ($p.io - $p1.io) / $elapsed)
    } else { $cpu = $p.cpuSec / $ageSec / $script:Cpus * 100.0; $io = 0.0 }
    $avg = $p.cpuSec / $ageSec / $script:Cpus * 100.0
    $perf[$procId] = @{ cpu = $cpu; avg = $avg; ageSec = $ageSec; ioBps = $io }
    if ($procId -ne 0) { $totalBusy += $cpu }
  }
  $sys.cpuPct = [Math]::Round([Math]::Min(100.0, $totalBusy), 1)

  # --- 名札 ---
  $entryOf = @{}
  foreach ($procId in $procs.Keys) {
    $p = $procs[$procId]
    $entryOf[$procId] = Find-Entry (($p.name -replace '\.exe$', '')) $p.cmd
  }

  # --- Claude セッションID（bash の環境変数に入っている） ---
  $sidByPid = @{}
  foreach ($procId in $procs.Keys) {
    $p = $procs[$procId]
    if ($p.name -eq 'bash.exe' -and $p.cmd) {
      $m = [regex]::Match($p.cmd, "CODEX_COMPANION_SESSION_ID='([^']+)'")
      if ($m.Success) {
        $sidByPid[$procId] = $m.Groups[1].Value
        $a = Get-ParentProc $procs $p; $hop = 0
        # いちばん近い claude.exe（＝そのセッション本体）にだけ付ける。もっと上（アプリ本体）に付けると、他のセッションまで同じIDになる
        while ($a -and $hop -lt 6) { if ($a.name -eq 'claude.exe') { if (-not $sidByPid.ContainsKey($a.pid)) { $sidByPid[$a.pid] = $m.Groups[1].Value }; break }; $a = Get-ParentProc $procs $a; $hop++ }
      }
    }
  }

  # --- グループ化 ---
  $gkey = @{}
  $members = @{}
  foreach ($procId in $procs.Keys) {
    $k = Get-GroupKey $procs $entryOf $gkey $procs[$procId]
    if (-not $members.ContainsKey($k)) { $members[$k] = New-Object System.Collections.ArrayList }
    [void]$members[$k].Add($procs[$procId])
  }

  $interp = '^(python|pythonw|py|node|pwsh|powershell|bash|wsl|java|javaw|ruby|php|go|cargo|dotnet)$'
  $rows = New-Object System.Collections.ArrayList
  $warnings = New-Object System.Collections.ArrayList
  $hidden = @{ n = 0; cpu = 0.0; memMB = 0.0 }
  $graceMin = $(if ($SpinMinutes -ge 0) { [Math]::Min(1.0, $SpinMinutes) } else { 1.0 })

  foreach ($k in $members.Keys) {
    $mem = @($members[$k] | Sort-Object { $_.start })
    $root = $mem[0]
    $entry = $entryOf[$root.pid]
    if ($k -like 'e:*') { $entry = $entryOf[$mem[0].pid] }
    $named = [bool]$entry
    $pids = @($mem | ForEach-Object { [int]$_.pid })
    $cpu = 0.0; $memMB = 0.0; $ioBps = 0.0; $maxProcCpu = 0.0; $spinMax = 0.0; $stdin = $false
    foreach ($p in $mem) {
      $pf = $perf[$p.pid]
      $cpu += $pf.cpu; $memMB += $p.ws / 1MB; $ioBps += $pf.ioBps
      if ($pf.cpu -gt $maxProcCpu) { $maxProcCpu = $pf.cpu }
      $sm = Get-SpinMinutes $p $pf.cpu $pf.avg $pf.ageSec $now
      if ($sm -gt $spinMax) { $spinMax = $sm }
      $nn = ($p.name -replace '\.exe$', '')
      if ($nn -match '^pythonw?[\d.]*$' -and $p.cmd -match '(?:^|\s)-\s*$' -and ($pf.ageSec / 60.0) -ge $graceMin) { $stdin = $true }
    }
    $ageSec = $perf[$root.pid].ageSec
    # 外部接続
    $ext = 0; $unk = 0; $hostList = New-Object System.Collections.ArrayList
    foreach ($p in $mem) {
      if ($netByPid.ContainsKey($p.pid)) {
        foreach ($ip in $netByPid[$p.pid].Keys) {
          $cnt = $netByPid[$p.pid][$ip]; $ext += $cnt
          $vd = Get-IpVerdict $ip $entry
          if (-not $vd.known) { $unk += $cnt }
          [void]$hostList.Add([ordered]@{ ip = $ip; host = $vd.host; rule = $vd.rule; known = $vd.known; n = $cnt })
        }
      }
    }
    $hostArr = @($hostList | Sort-Object @{ e = { $_.known } }, @{ e = { -$_.n } } | Select-Object -First 8)

    # 見せる行か
    $rootNN = ($root.name -replace '\.exe$', '')
    $visible = $named -or ($cpu -ge 1.0) -or ($memMB -ge 300) -or ($ext -gt 0) -or ($rootNN -match $interp) -or $stdin
    if (-not $visible) { $hidden.n += $pids.Count; $hidden.cpu += $cpu; $hidden.memMB += $memMB; continue }

    # 親連鎖
    $chain = @(); $a = Get-ParentProc $procs $root; $hop = 0
    while ($a -and $hop -lt 6) { $chain += $a.name; $a = Get-ParentProc $procs $a; $hop++ }
    # セッションID
    $sid = ''
    $a = $root; $hop = 0
    while ($a -and $hop -lt 14) { if ($sidByPid.ContainsKey($a.pid)) { $sid = $sidByPid[$a.pid]; break }; $a = Get-ParentProc $procs $a; $hop++ }
    $sidTitle = $(if ($sid) { Get-SessionTitle $sid } else { '' })

    $label = $(if ($named) { [string]$entry.名札 } else { '名前の分からないプログラム（' + $root.name + '）' })
    $maker = $(if ($named) { '' } else { Get-Maker $root.exe })
    $expect = $(if ($named) { [string]$entry.想定 } else { '名札なし' })
    $stopLv = Get-StopLevel $entry $rootNN
    $gid = 'g' + $root.pid + '_' + ([DateTimeOffset]::new($root.start)).ToUnixTimeSeconds()
    $flags = New-Object System.Collections.ArrayList

    # --- 赤の判定 ---
    $spinWatch = (-not $named) -or ($entry -and $entry.空回り監視)
    $spinThr = 70.0 / $script:Cpus
    if ($stdin) {
      [void]$flags.Add('空回り')
      [void]$warnings.Add([ordered]@{ kind = '空回り'; gid = $gid; title = $label; reason = '入力待ちのまま動き続けている Python（python.exe -）です。仕事をしていない可能性が高く、CPUを使い続けることもあります。'; advice = '止めて大丈夫なことがほとんどです。' })
    } elseif ($spinWatch -and $maxProcCpu -ge $spinThr -and $spinMax -ge $spinMin) {
      [void]$flags.Add('空回り')
      [void]$warnings.Add([ordered]@{ kind = '空回り'; gid = $gid; title = $label; reason = ('頭脳（CPU）を1コア分以上、{0} 以上使い続けています（いま {1}%）。' -f (Format-Age ([Math]::Max($spinMax, 0) * 60)), [Math]::Round($maxProcCpu, 1)); advice = '何の作業か分からなければ、止めて大丈夫な可能性が高いです。' })
    }
    if ($named -and $expect -eq '作業中だけ' -and ($ageSec / 3600.0) -ge $leftHrs) {
      [void]$flags.Add('置き去り')
      [void]$warnings.Add([ordered]@{ kind = '置き去り'; gid = $gid; title = $label; reason = ('作業中だけのはずなのに、{0} 生きています。' -f (Format-Age $ageSec)); advice = $(if ($entry.助言) { [string]$entry.助言 } else { '使い終わっていれば止めてください。' }) })
    }
    if ($named -and $expect -eq '残っていたら警告') {
      [void]$flags.Add('置き去り')
      [void]$warnings.Add([ordered]@{ kind = '置き去り'; gid = $gid; title = $label; reason = ('「残っていたら警告」の名札が、{0} 生きています。' -f (Format-Age $ageSec)); advice = $(if ($entry.助言) { [string]$entry.助言 } else { '使い終わっていれば止めてください。' }) })
    }
    $strict = (-not $named) -or ($entry.接続 -ne '任意')
    if ($netWarn -and $strict -and $unk -gt 0) {
      [void]$flags.Add('未知の接続')
      $names = @($hostArr | Where-Object { -not $_.known } | ForEach-Object { if ($_.host) { $_.host } else { $_.ip } } | Select-Object -First 4)
      [void]$warnings.Add([ordered]@{ kind = '未知の接続'; gid = $gid; title = $label; reason = ('許可リストにない相手へ {0} 件つながっています：{1}' -f $unk, ($names -join '、')); advice = 'この通信に心当たりがなければ、止めて、台帳で確認してください。' })
    }
    $overTxt = @()
    if ($named -and $entry.目安) {
      if ($entry.目安.CPU -and $cpu -gt [double]$entry.目安.CPU) { $overTxt += ('CPU {0}%（目安 {1}%）' -f [Math]::Round($cpu, 1), $entry.目安.CPU) }
      if ($entry.目安.メモリMB -and $memMB -gt [double]$entry.目安.メモリMB) { $overTxt += ('メモリ {0:N0} MB（目安 {1:N0} MB）' -f $memMB, [double]$entry.目安.メモリMB) }
    }
    if ($overTxt.Count -gt 0) {
      [void]$flags.Add('目安超え')
      [void]$warnings.Add([ordered]@{ kind = '目安超え'; gid = $gid; title = $label; reason = ('台帳の目安を超えています：' + ($overTxt -join '、')); advice = $(if ($entry.助言) { [string]$entry.助言 } else { '' }) })
    }

    $sub = ''
    if ($named -and $entry.id -eq 'claude-code-session') { $sub = 'PID ' + $root.pid + $(if ($sid) { '・セッション ' + $sid.Substring(0, [Math]::Min(8, $sid.Length)) } else { '' }) }
    elseif ((-not $named) -or $entry.束ね -eq '個別') {
      $c = Hide-Secrets ([string]$root.cmd)
      if ($c) { $c = ($c -replace '^"[^"]*"\s*', '') -replace '^\S+?\.exe\s*', ''; $sub = ($root.name + ' ' + $c).Trim() } else { $sub = $root.name }
      if ($sub.Length -gt 60) { $sub = $sub.Substring(0, 60) + '…' }
    }
    $row = [ordered]@{
      gid = $gid; sub = $sub; 所属 = $(if ($named) { [string]$entry.所属 } else { '名札なし' }); 名札 = $label; 想定 = $expect; 停止 = $stopLv
      停止方法 = $(if ($named -and $entry.停止方法) { [string]$entry.停止方法 } else { '' })
      説明 = $(if ($named) { [string]$entry.説明 } else { 'このPCの名札の一覧にないプログラムです。' + $(if ($maker) { '作成元：' + $maker + '。' } else { '' }) })
      助言 = $(if ($named) { [string]$entry.助言 } else { '何のためのプログラムか分からないときは、止める前に詳しい人に聞いてください。' })
      named = $named; entryId = $(if ($named) { [string]$entry.id } else { '' })
      pids = $pids; rootPid = [int]$root.pid; startMs = [DateTimeOffset]::new($root.start).ToUnixTimeMilliseconds(); ageSec = [int]$ageSec
      cpu = [Math]::Round($cpu, 1); maxCpu = [Math]::Round($maxProcCpu, 1); memMB = [Math]::Round($memMB); ioMBs = [Math]::Round($ioBps / 1MB, 2)
      ext = $ext; unknown = $unk; hosts = $hostArr
      sessionId = $sid; sessionTitle = $sidTitle
      cmd = $(if ($root.cmd) { $cs = Hide-Secrets $root.cmd; $cs.Substring(0, [Math]::Min(600, $cs.Length)) } else { '' })
      exe = $root.exe; maker = $maker; chain = $chain; flags = @($flags)
      目安 = $(if ($named -and $entry.目安) { [ordered]@{ cpu = $entry.目安.CPU; memMB = $entry.目安.メモリMB } } else { $null })
    }
    [void]$rows.Add($row)
    $script:LastGroups[$gid] = @{ members = @($mem | ForEach-Object { @{ pid = [int]$_.pid; startMs = [DateTimeOffset]::new($_.start).ToUnixTimeMilliseconds() } }); rootPid = [int]$root.pid; level = $stopLv; method = $row.停止方法; label = $label }
  }

  $sorted = @($rows | Sort-Object @{ e = { if ($_.flags.Count -gt 0) { 0 } else { 1 } } }, @{ e = { $_.所属 } }, @{ e = { -$_.cpu } }, @{ e = { -$_.memMB } })
  $data = [ordered]@{
    generatedAt = [DateTimeOffset]::new($now).ToUnixTimeMilliseconds()
    generatedText = $now.ToString('yyyy-MM-dd HH:mm:ss')
    cpus = $script:Cpus; sampleSeconds = $SampleSeconds
    system = $sys
    rows = $sorted
    warnings = @($warnings)
    hidden = [ordered]@{ count = $hidden.n; cpu = [Math]::Round($hidden.cpu, 1); memMB = [Math]::Round($hidden.memMB) }
    settings = [ordered]@{ spinMinutes = $spinMin; leftoverHours = $leftHrs; netWarn = $netWarn; hasOwnLedger = $script:Ledger.HasOwn }
    procexp = $(if (Test-Path 'C:\Tools\ProcessExplorer\procexp64.exe') { 'C:\Tools\ProcessExplorer\procexp64.exe' } else { '' })
  }
  $data.diagnosis = Get-Diagnosis $data
  $script:LastData = $data
  return $data
}

# ============================================================
#  6. ワンボタン診断（ルール式・無料・このPCの中だけで完結）
# ============================================================
function Get-Word([string]$kind, $pct) {
  if ($pct -eq $null) { return '不明' }
  $p = [double]$pct
  switch ($kind) {
    'cpu'  { if ($p -lt 25) { return 'ゆったり' } elseif ($p -lt 55) { return 'ふつう' } elseif ($p -lt 80) { return '忙しい' } else { return '満杯' } }
    'mem'  { if ($p -lt 60) { return 'ゆったり' } elseif ($p -lt 75) { return 'ふつう' } elseif ($p -lt 88) { return '混んでいる' } else { return '満杯に近い' } }
    'disk' { if ($p -lt 20) { return 'ゆったり' } elseif ($p -lt 50) { return 'ふつう' } elseif ($p -lt 80) { return '忙しい' } else { return '混み合っている' } }
  }
  return ''
}

function Get-RowLabel($r) {
  if ($r.sub -and $r.named) { return ([string]$r.名札 + '：' + [string]$r.sub) }
  return [string]$r.名札
}

function Get-Diagnosis($d) {
  $sys = $d.system
  $rows = @($d.rows)
  $FL = New-Object System.Collections.ArrayList   # ⚠ $F と $f は同じ変数なので、名前を分ける
  $covered = @{}
  $rowOf = @{}; foreach ($r in $rows) { $rowOf[$r.gid] = $r }

  # --- A. 赤の警告（具体的な犯人） ---
  $byGid = @{}
  foreach ($w in @($d.warnings)) { if (-not $byGid.ContainsKey($w.gid)) { $byGid[$w.gid] = @() }; $byGid[$w.gid] += $w }
  foreach ($r in $rows) {
    $gid = $r.gid; if (-not $byGid.ContainsKey($gid)) { continue }
    $ws = @($byGid[$gid]); $kinds = @($ws | ForEach-Object { $_.kind })
    $sev = 1; $title = ''
    $nm = Get-RowLabel $r
    if ($kinds -contains '空回り') { $sev = 2; $title = ('「{0}」が、何も仕事をしないまま頭脳（CPU）を使い続けています' -f $nm) }
    elseif ($kinds -contains '置き去り') { $sev = $(if ($r.memMB -ge 1000) { 2 } else { 1 }); $title = ('使い終わったはずの「{0}」が残っています' -f $nm) }
    elseif ($kinds -contains '目安超え') {
      $over = 1.0
      if ($r.目安 -and $r.目安.memMB -and $r.memMB -gt 0) { $over = [Math]::Max($over, $r.memMB / [double]$r.目安.memMB) }
      if ($r.目安 -and $r.目安.cpu -and $r.cpu -gt 0) { $over = [Math]::Max($over, $r.cpu / [double]$r.目安.cpu) }
      $sev = $(if ($over -ge 1.5) { 2 } else { 1 })
      $title = ('「{0}」が、いつもより多くPCの力を使っています' -f $nm)
    }
    else { $sev = 1; $title = ('「{0}」が、見慣れない相手と通信しています（安全の確認）' -f $nm) }
    $why = ((@($ws | ForEach-Object { $_.reason })) -join ' ')
    $todo = ((@($ws | ForEach-Object { $_.advice } | Where-Object { $_ } | Select-Object -Unique)) -join ' ')
    if ($r.説明) { $why = $why + '（' + $r.説明 + '）' }
    $gids = @(); if ($r.停止 -ne '不可') { $gids = @($r.gid) }
    [void]$FL.Add([ordered]@{ sev = $sev; key = 'warn:' + $gid; title = $title; why = $why; todo = $todo; gids = $gids })
    $covered[$gid] = $true
  }

  # --- B. 全体の様子から ---
  $cpuT = [double]$sys.cpuPct
  $topCpu = @($rows | Sort-Object { -$_.cpu } | Where-Object { $_.cpu -ge 3 } | Select-Object -First 3)
  $first = $topCpu | Select-Object -First 1
  $names = (@($topCpu | ForEach-Object { '「{0}」{1}%' -f (Get-RowLabel $_), $_.cpu })) -join '、'
  if ($cpuT -ge 70 -and -not ($first -and $covered[$first.gid] -and $first.cpu -ge $cpuT * 0.5)) {
    $sev = $(if ($cpuT -ge 85) { 2 } else { 1 })
    $title = $(if ($first -and $first.cpu -ge $cpuT * 0.5) { '「{0}」が頭脳（CPU）の大半を使っています' -f (Get-RowLabel $first) } else { '頭脳（CPU）がずっと忙しい状態です（{0}%）' -f $cpuT })
    $todo = $(if ($first -and $first.助言) { [string]$first.助言 } else { 'それが今やっている作業なら終わるまで待ってください。使っていなければ閉じてください。' })
    $gids = @(); if ($first -and $first.停止 -ne '不可' -and -not $covered[$first.gid]) { $gids = @($first.gid) }
    [void]$FL.Add([ordered]@{ sev = $sev; key = 'cpu'; title = $title; why = ('PC全体の頭脳（CPU）の {0}% が使われていて、ほかの作業が順番待ちになっています。使っている上位：{1}。' -f $cpuT, $names); todo = $todo; gids = $gids })
    if ($first) { $covered[$first.gid] = $true }
  } elseif ($first -and $first.cpu -ge 20 -and -not $covered[$first.gid]) {
    $gids = @(); if ($first.停止 -ne '不可') { $gids = @($first.gid) }
    [void]$FL.Add([ordered]@{ sev = 1; key = 'cpu1'; title = ('「{0}」が頭脳（CPU）を目立って使っています（{1}%）' -f (Get-RowLabel $first), $first.cpu); why = ('全体では {0}% ですが、1つのプログラムで {1}% を使っています。{2}' -f $cpuT, $first.cpu, $first.説明); todo = $(if ($first.助言) { [string]$first.助言 } else { '今やっている作業なら終わるまで待ってください。' }); gids = $gids })
    $covered[$first.gid] = $true
  }

  $memP = [double]$sys.memPct
  if ($memP -ge 75) {
    $topMem = @($rows | Sort-Object { -$_.memMB } | Select-Object -First 3)
    $mnames = (@($topMem | ForEach-Object { '「{0}」{1:N0} MB' -f (Get-RowLabel $_), $_.memMB })) -join '、'
    $pick = $topMem | Where-Object { -not $covered[$_.gid] } | Select-Object -First 1
    $gids = @(); if ($pick -and $pick.停止 -ne '不可' -and $pick.memMB -ge 800) { $gids = @($pick.gid) }
    $todo = $(if ($pick -and $pick.助言) { [string]$pick.助言 } else { '大きいものから順に、使っていないものを閉じてください。' })
    [void]$FL.Add([ordered]@{ sev = $(if ($memP -ge 90) { 2 } else { 1 }); key = 'mem'; title = ('メモリ（作業机）が {0}% 埋まっています' -f $memP)
      why = ('作業机がいっぱいに近いと、PCは遅い保管庫（ディスク）を机の代わりに使い始め、全体が急に遅くなります。使っている上位：{0}。' -f $mnames); todo = $todo; gids = $gids })
    if ($pick -and $gids.Count -gt 0) { $covered[$pick.gid] = $true }
  }

  if ($sys.diskBusy -ne $null -and [double]$sys.diskBusy -ge 60) {
    $topIo = @($rows | Sort-Object { -$_.ioMBs } | Where-Object { $_.ioMBs -ge 1 } | Select-Object -First 3)
    $inames = (@($topIo | ForEach-Object { '「{0}」{1} MB/秒' -f (Get-RowLabel $_), $_.ioMBs })) -join '、'
    $pick = $topIo | Select-Object -First 1
    $todo = $(if ($pick -and $pick.助言) { [string]$pick.助言 } else { '更新・同期・ウイルス点検などの一時的な作業なら、終わるまで待ってください。' })
    [void]$FL.Add([ordered]@{ sev = $(if ([double]$sys.diskBusy -ge 85) { 2 } else { 1 }); key = 'disk'; title = ('保管庫（ディスク）の出し入れが混み合っています（{0}%）' -f $sys.diskBusy)
      why = ('保管庫の読み書き待ちがあると、ほかの作業が止まったように感じます。' + $(if ($inames) { '出し入れの多い上位：' + $inames + '。' } else { '' })); todo = $todo; gids = @() })
  }

  if ($sys.freeGB -ne $null -and $sys.totalGB) {
    $freePct = [double]$sys.freeGB / [double]$sys.totalGB * 100
    if ([double]$sys.freeGB -lt 20 -or $freePct -lt 12) {
      [void]$FL.Add([ordered]@{ sev = $(if ([double]$sys.freeGB -lt 10 -or $freePct -lt 8) { 2 } else { 1 }); key = 'space'
        title = ('{0} ドライブの空きが少なくなっています（残り {1} GB）' -f $sys.drive, $sys.freeGB)
        why = '空きが少ないと、Windows が作業用の場所を作れず、動作が遅くなります。'
        todo = 'ごみ箱を空にし、ダウンロードや使っていない大きなファイルを整理してください。「設定 → システム → 記憶域」が便利です。'; gids = @() })
    }
  }

  $up = [double]$sys.uptimeDays
  if ($up -ge 7) {
    [void]$FL.Add([ordered]@{ sev = $(if ($up -ge 14) { 1 } else { 0 }); key = 'uptime'; title = ('{0} 日間、再起動していません' -f [int]$up)
      why = '長く使い続けると、見えない不具合がたまって、だんだん重くなります。'
      todo = '保存してから「再起動」を選んでください（「シャットダウン」は高速スタートアップのため、再起動にならないことがあります）。'; gids = @() })
  }

  # --- C. 一時的な忙しさ（名札の助言を使う） ---
  $n = 0
  foreach ($r in @($rows | Sort-Object { -($_.cpu + $_.ioMBs * 2) })) {
    if ($n -ge 2) { break }
    if (-not $r.named -or $covered[$r.gid] -or -not $r.助言) { continue }
    if ($r.entryId -eq 'browser') { continue }
    if ($r.cpu -ge 25 -or $r.maxCpu -ge 8 -or $r.ioMBs -ge 5) {
      $gl = @(); if ($r.停止 -ne '不可') { $gl = @($r.gid) }
      [void]$FL.Add([ordered]@{ sev = 1; key = 'busy:' + $r.gid; title = ('「{0}」が忙しくしています' -f (Get-RowLabel $r))
        why = ('{0}（いま 頭脳 {1}%・出し入れ {2} MB/秒）' -f $r.説明, $r.cpu, $r.ioMBs); todo = [string]$r.助言; gids = $gl })
      $covered[$r.gid] = $true; $n++
    }
  }
  foreach ($r in $rows) {
    if ($r.entryId -eq 'browser' -and $r.memMB -ge 3000 -and -not $covered[$r.gid]) {
      [void]$FL.Add([ordered]@{ sev = 1; key = 'browser'; title = ('ブラウザが {0:N1} GB のメモリを使っています（タブが多いかもしれません）' -f ($r.memMB / 1024.0))
        why = '開いているタブの数だけ、作業机（メモリ）を使います。'; todo = [string]$r.助言; gids = @() })
      break
    }
  }

  $ord = 0; foreach ($fd in $FL) { $fd['ord'] = $ord; $ord++ }   # Sort-Object は安定でないので、挿入順を持たせる
  $ordered = @($FL | Sort-Object @{ e = { -$_.sev } }, @{ e = { $_.ord } } | Select-Object -First 6)
  $maxSev = 0; foreach ($fd in $ordered) { if ($fd.sev -gt $maxSev) { $maxSev = $fd.sev } }
  $level = $(if ($maxSev -ge 2) { 'bad' } elseif ($maxSev -eq 1) { 'warn' } else { 'ok' })
  $top = $ordered | Select-Object -First 1
  if ($level -eq 'bad') { $headline = '重くなっている原因が見つかりました。' ; $lead = $top.title }
  elseif ($level -eq 'warn') { $headline = '少し負担がかかっています。'; $lead = $top.title }
  else { $headline = 'いまは快適です。重くなる原因は見つかりませんでした。'; $lead = $(if ($top) { 'ヒント：' + $top.title } else { '' }) }
  return [ordered]@{
    level = $level; headline = $headline; lead = $lead
    findings = @($ordered)
    gauges = [ordered]@{
      cpu = [ordered]@{ pct = $cpuT; word = (Get-Word 'cpu' $cpuT) }
      mem = [ordered]@{ pct = $memP; word = (Get-Word 'mem' $memP); usedMB = $sys.memUsedMB; totalMB = $sys.memTotalMB }
      disk = [ordered]@{ pct = $sys.diskBusy; word = (Get-Word 'disk' $sys.diskBusy) }
    }
  }
}

# ============================================================
#  7. HTML と、ローカルだけで待ち受けるページサーバー
# ============================================================
function Build-Html($data, [string]$mode, [string]$token) {
  $tpl = Get-Content -LiteralPath (Join-Path $script:Root 'page_template.html') -Raw -Encoding UTF8
  $dj = $(if ($data) { ConvertTo-SafeJson $data } else { 'null' })
  return $tpl.Replace('@@MODE@@', $mode).Replace('@@TOKEN@@', $token).Replace('@@DATA@@', $dj)
}

function Send-Bytes($ctx, [int]$code, [string]$ctype, [byte[]]$bytes) {
  $res = $ctx.Response
  $res.StatusCode = $code
  $res.ContentType = $ctype
  $res.Headers.Add('Cache-Control', 'no-store')
  $res.Headers.Add('X-Content-Type-Options', 'nosniff')
  $res.Headers.Add('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src data:")
  $res.ContentLength64 = $bytes.Length
  if ($bytes.Length -gt 0) { $res.OutputStream.Write($bytes, 0, $bytes.Length) }
  $res.OutputStream.Close()
}
function Send-Text($ctx, [int]$code, [string]$ctype, [string]$text) {
  Send-Bytes $ctx $code ($ctype + '; charset=utf-8') ([Text.Encoding]::UTF8.GetBytes($text))
}

function Get-OwnAncestors {
  $set = @{}
  $procs = @{}
  Get-CimInstance Win32_Process | ForEach-Object { $procs[[int]$_.ProcessId] = [int]$_.ParentProcessId }
  $a = [int]$PID; $hop = 0
  while ($a -and $procs.ContainsKey($a) -and $hop -lt 30) { $set[$a] = 1; $a = $procs[$a]; $hop++ }
  return $set
}

function Invoke-StopGroup([int]$rootPid, [int64]$startMs) {
  $g = $null
  foreach ($v in $script:LastGroups.Values) { if ($v.rootPid -eq $rootPid) { $g = $v; break } }
  if (-not $g) { return @{ ok = $false; message = '一覧が古いようです。もう一度「調べる」を押してから止めてください。' } }
  if ($g.level -eq '不可') { return @{ ok = $false; message = '「' + $g.label + '」は止められない設定です（止めると困るものです）。' } }
  if ($g.method -eq 'wsl-shutdown') {
    try { Start-Process -FilePath 'wsl.exe' -ArgumentList '--shutdown' -WindowStyle Hidden -Wait } catch { return @{ ok = $false; message = 'wsl --shutdown に失敗しました: ' + $_.Exception.Message } }
    return @{ ok = $true; message = '「' + $g.label + '」を止めました（wsl --shutdown）。' ; stopped = @() }
  }
  $all = @(Get-CimInstance Win32_Process)
  $kids = @{}
  foreach ($p in $all) { $pp = [int]$p.ParentProcessId; if (-not $kids.ContainsKey($pp)) { $kids[$pp] = @() }; $kids[$pp] += [int]$p.ProcessId }
  $startOf = @{}; foreach ($p in $all) { if ($p.CreationDate) { $startOf[[int]$p.ProcessId] = [DateTimeOffset]::new($p.CreationDate).ToUnixTimeMilliseconds() } }
  $own = Get-OwnAncestors
  $target = @{}
  $queue = New-Object System.Collections.Queue
  foreach ($m in $g.members) {
    if ($startOf.ContainsKey($m.pid) -and [Math]::Abs($startOf[$m.pid] - $m.startMs) -le 2000) { $queue.Enqueue($m.pid) }
  }
  while ($queue.Count -gt 0) {
    $c = [int]$queue.Dequeue()
    if ($target.ContainsKey($c)) { continue }
    $target[$c] = 1
    if ($kids.ContainsKey($c)) { foreach ($k in $kids[$c]) { $queue.Enqueue($k) } }
  }
  $ids = @($target.Keys | Where-Object { -not $own.ContainsKey([int]$_) } | Sort-Object -Descending)
  if ($ids.Count -eq 0) { return @{ ok = $false; message = 'もう終わっているか、別のプログラムに入れ替わっていたため、何も止めませんでした。' } }
  $stopped = @(); $failed = @()
  foreach ($i in $ids) {
    try { Stop-Process -Id $i -Force -ErrorAction Stop; $stopped += $i } catch { $failed += $i }
  }
  $msg = '「' + $g.label + '」を止めました（' + $stopped.Count + ' 個）。'
  if ($failed.Count -gt 0) { $msg += ' 止められなかったもの: ' + ($failed -join ',') + '（権限が足りない可能性）' }
  return @{ ok = ($stopped.Count -gt 0); message = $msg; stopped = $stopped; failed = $failed }
}

function Handle-Request($ctx, [string]$token) {
  $req = $ctx.Request
  $path = $req.Url.AbsolutePath
  $q = $req.QueryString
  $hostH = [string]$req.Headers['Host']
  if ($hostH -ne ('127.0.0.1:' + $Port) -and $hostH -ne ('localhost:' + $Port)) { Send-Text $ctx 403 'text/plain' 'forbidden host'; return }
  $authed = ([string]$q['token'] -eq $token)
  switch ($path) {
    '/' { Send-Text $ctx 200 'text/html' (Build-Html $null 'serve' $token) }
    '/ping' { if (-not $authed) { Send-Text $ctx 403 'text/plain' 'forbidden'; return }; Send-Bytes $ctx 204 'text/plain' ([byte[]]@()) }
    '/data' {
      if (-not $authed) { Send-Text $ctx 403 'text/plain' 'forbidden'; return }
      $d = $script:LastData
      if (-not $d -or [string]$q['fresh'] -eq '1' -or (([DateTimeOffset]::Now.ToUnixTimeMilliseconds() - $d.generatedAt) -gt 20000)) { $d = Invoke-Collect }
      Send-Text $ctx 200 'application/json' (ConvertTo-SafeJson $d)
    }
    '/stop' {
      if (-not $authed) { Send-Text $ctx 403 'text/plain' 'forbidden'; return }
      $r = Invoke-StopGroup ([int]$q['pid']) ([int64]$q['start'])
      Send-Text $ctx 200 'application/json' (ConvertTo-SafeJson $r)
    }
    '/procexp' {
      if (-not $authed) { Send-Text $ctx 403 'text/plain' 'forbidden'; return }
      $exe = 'C:\Tools\ProcessExplorer\procexp64.exe'
      if (Test-Path $exe) { Start-Process -FilePath $exe -ArgumentList '/accepteula'; Send-Text $ctx 200 'application/json' '{"ok":true}' }
      else { Send-Text $ctx 200 'application/json' '{"ok":false,"message":"Process Explorer が見つかりません"}' }
    }
    '/quit' {
      if (-not $authed) { Send-Text $ctx 403 'text/plain' 'forbidden'; return }
      $script:QuitFlag = $true
      Send-Text $ctx 200 'application/json' '{"ok":true}'
    }
    default { Send-Text $ctx 404 'text/plain' 'not found' }
  }
}

function Start-PageServer {
  $token = [guid]::NewGuid().ToString('N')
  $prefix = 'http://127.0.0.1:' + $Port + '/'
  $listener = New-Object System.Net.HttpListener
  $listener.Prefixes.Add($prefix)
  try { $listener.Start() }
  catch {
    Write-Host ('すでに起動しているか、ポート ' + $Port + ' が使えません。起動済みのページを開きます。')
    if ($Open) { Start-Process $prefix }
    return
  }
  try { $Host.UI.RawUI.WindowTitle = '常駐点検サーバー（ページを閉じて ' + $IdleMinutes + ' 分で自動終了）' } catch { }
  Write-Host ('常駐点検サーバーを起動しました: ' + $prefix)
  Write-Host ('ページを閉じて ' + $IdleMinutes + ' 分たつと、自分で終了します（ページの「いますぐサーバーを終了する」でも止まります）。このウィンドウを閉じるとサーバーも止まります。常駐点検.bat からは隠れて動きます。')
  if ($Open) { Start-Process $prefix }
  $script:QuitFlag = $false
  $last = Get-Date
  $done = $false
  while (-not $done -and $listener.IsListening -and -not $script:QuitFlag) {
    $ar = $listener.BeginGetContext($null, $null)
    $got = $false
    while (-not $got) {
      if ($ar.AsyncWaitHandle.WaitOne(1000)) { $got = $true; break }
      if (((Get-Date) - $last).TotalMinutes -ge $IdleMinutes) { $done = $true; break }
    }
    if ($done) { break }
    $ctx = $listener.EndGetContext($ar)
    try { Handle-Request $ctx $token }
    catch { try { Send-Text $ctx 500 'text/plain' ('error: ' + $_.Exception.Message) } catch { } }
    if ($ctx.Request.Url.AbsolutePath -ne '/' -or $true) { $last = Get-Date }
  }
  try { $listener.Stop(); $listener.Close() } catch { }
  Write-Host ('常駐点検サーバーを終了しました（' + (Get-Date -Format 'HH:mm:ss') + '）。')
}

# ============================================================
#  8. 警告メール（赤が1件以上あるときだけ）
# ============================================================
function Send-AlertMail($data) {
  $w = @($data.warnings)
  if ($w.Count -lt 1) { Write-Host '赤の警告はありません。メールは送りません。'; return $false }
  $mailPy = Join-Path $script:Root 'send_mail.py'
  if (-not (Test-Path -LiteralPath $mailPy)) { Write-Host 'send_mail.py が無いので、メールは送れません。'; return $false }
  $py = $null; try { $py = (Get-Command py.exe -ErrorAction Stop).Source } catch { }
  if (-not $py -and (Test-Path 'C:\Windows\py.exe')) { $py = 'C:\Windows\py.exe' }
  if (-not $py) { Write-Host 'py.exe が無いので、メールは送れません。'; return $false }
  $prefix = $(if ($TestMail) { '【常駐点検】テスト：' } else { '【常駐点検】' })
  $subject = $prefix + '赤の警告 ' + $w.Count + ' 件：' + $w[0].title
  if ($w.Count -gt 1) { $subject += ' ほか' }
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.AppendLine('今朝の常駐点検で、赤の警告が ' + $w.Count + ' 件ありました（' + $data.generatedText + '）。')
  [void]$sb.AppendLine('')
  $i = 1
  foreach ($x in $w) {
    [void]$sb.AppendLine(('{0}. [{1}] {2}' -f $i, $x.kind, $x.title))
    [void]$sb.AppendLine('   ' + $x.reason)
    if ($x.advice) { [void]$sb.AppendLine('   → ' + $x.advice) }
    $i++
  }
  [void]$sb.AppendLine('')
  [void]$sb.AppendLine('停止ボタンつきのページ: 常駐点検フォルダの「常駐点検.bat」をダブルクリック')
  [void]$sb.AppendLine('今朝の記録: 同じフォルダの「常駐点検.html」')
  if ($TestMail) { [void]$sb.AppendLine(''); [void]$sb.AppendLine('（これは動作確認のテストメールです）') }
  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('proc_check_mail_' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  $sf = Join-Path $tmp 'subject.txt'; $bf = Join-Path $tmp 'body.txt'
  [IO.File]::WriteAllText($sf, $subject, $utf8); [IO.File]::WriteAllText($bf, $sb.ToString(), $utf8)
  & $py -I -X utf8 $mailPy --subject-file $sf --body-file $bf
  $rc = $LASTEXITCODE
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  if ($rc -eq 0) { Write-Host ('警告メールを送りました（' + $w.Count + ' 件）。'); return $true }
  Write-Host ('警告メールの送信に失敗しました（終了コード ' + $rc + '）。'); return $false
}

# ============================================================
#  9. 実行
# ============================================================
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
Import-Ledger
if (-not ($Serve -or $Report -or $Json)) { $Serve = [switch]$true; $Open = [switch]$true }

if ($Json) {
  $d = Invoke-Collect
  Write-Output (ConvertTo-SafeJson $d)
  exit 0
}
if ($Report) {
  $d = Invoke-Collect
  $out = $(if ($OutHtml) { $OutHtml } else { Join-Path $script:Root '常駐点検.html' })
  $html = Build-Html $d 'report' ''
  [IO.File]::WriteAllText($out, $html, (New-Object System.Text.UTF8Encoding($false)))
  Write-Host ('常駐点検.html を書きました: ' + $out)
  Write-Host ('赤の警告: ' + @($d.warnings).Count + ' 件 ／ 診断: ' + $d.diagnosis.level + ' ／ ' + $d.diagnosis.headline)
  foreach ($x in @($d.warnings)) { Write-Host ('  [' + $x.kind + '] ' + $x.title + ' … ' + $x.reason) }
  if ($Mail -or $TestMail) { [void](Send-AlertMail $d) }
  exit 0
}
if ($Serve) { Start-PageServer }
