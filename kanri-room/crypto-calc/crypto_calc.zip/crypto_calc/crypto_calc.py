r"""
暗号資産 計算書ツール（総平均法）

input\ に置いた各取引所のデータを読み込み、国税庁「暗号資産の計算書（総平均法用）」
と同じ計算を行って、次の3つを output\ に出力する。

  1) 暗号資産の計算書_YYYY.xlsx … 提出用（国税庁様式・数式入り）
  2) レポート_YYYY.html          … 確認用（計算過程が読める形）
  3) 繰越残高_YYYY.json          … 翌年の年始残高（総平均法は繰越が命）

使い方:
  run.bat をダブルクリック（既定で当年を計算）
  または
  py crypto_calc.py --year 2025
  py crypto_calc.py --year 2025 --absorption 3962000   ← 税ゼロ吸収枠と比較する

対応取引所: OKJ（手入力JSON）/ メルコイン（月次CSV）/ GMOコイン（年間取引報告書CSV）

作成: 2026-08-21 監理幕僚
"""

from __future__ import annotations

import argparse
import datetime
import os
import sys
from decimal import Decimal

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import calc          # noqa: E402
import parsers       # noqa: E402
import report        # noqa: E402

INPUT_DIR = os.path.join(BASE_DIR, "input")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
TEMPLATE = os.path.join(BASE_DIR, "templates", "暗号資産の計算書_総平均法_template.xlsx")

DEFAULT_NAME = ""   # 氏名は --name で指定する（計算書に印字される）


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="暗号資産の計算書（総平均法）を自動生成する",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--year", type=int, default=datetime.date.today().year - 1,
                    help="対象年（西暦）。既定は前年")
    ap.add_argument("--name", default=DEFAULT_NAME,
                    help="氏名（計算書に印字）。省略時は空欄のまま出力する")
    ap.add_argument("--absorption", type=str, default=None,
                    help="税ゼロ吸収枠（所得控除＋事業等の赤字）。指定すると残り枠を表示")
    ap.add_argument("--input", default=INPUT_DIR, help="入力フォルダ")
    ap.add_argument("--output", default=OUTPUT_DIR, help="出力フォルダ")
    args = ap.parse_args(argv)

    year = args.year
    os.makedirs(args.output, exist_ok=True)

    print("=" * 66)
    print(f" 暗号資産 計算書ツール（総平均法）　対象: {year}年分（令和{year-2018}年分）")
    print("=" * 66)

    # ---- 1. 読み込み ----
    print("\n[1/4] 入力データを読み込み中 ...")
    trades, margins, openings, warnings = parsers.collect_all(args.input, year)

    if not trades and not margins:
        print("\n  取引データが1件も読み込めませんでした。")
        print(f"  input フォルダ: {args.input}")
        print("  次のファイルを置いてください:")
        print("    ・メルコイン … 月次CSV（2025 01.csv 〜、または mercoin_*.csv）")
        print("    ・GMOコイン  … gmo_2025.csv（年間取引報告書）")
        print(f"    ・OKJ        … okj_{year}.json（PDFから手入力）")
        print(f"    ・年始残高   … opening_{year}.json（前年の繰越残高_*.json をコピー）")
        return 1

    by_source: dict[str, int] = {}
    for t in trades:
        by_source[t.source] = by_source.get(t.source, 0) + 1
    for src, n in sorted(by_source.items()):
        print(f"      {src}: {n} 件")
    if margins:
        print(f"      証拠金取引(FX): {len(margins)} 銘柄")
    if openings:
        print(f"      年始残高: {len(openings)} 通貨")
    else:
        print("      年始残高: なし（全通貨ゼロとして計算）")

    # ---- 2. 計算 ----
    # 無償取得（取得価額0）は、本来は取得時の時価が雑所得になる。警告として可視化する。
    for t in trades:
        if t.amount_jpy == 0:
            warnings.append({
                "file": t.source, "line": t.date,
                "reason": f"{t.currency} を金額0で{'取得' if t.kind=='buy' else '譲渡'}"
                          f"（数量 {t.quantity}）。エアドロップ・ステーキング報酬・出庫が疑われる。"
                          "無償取得は本来『取得時の時価』が雑所得になるため要確認",
            })

    print("\n[2/4] 総平均法で計算中 ...")
    try:
        results = calc.calculate(trades, openings, margins)
    except ValueError as ex:
        print(f"\n  計算エラー: {ex}")
        if "年末残高数量が負" in str(ex):
            print("  売却数量が保有数量を超えています。年始残高（前年繰越）の設定漏れ、")
            print("  または取引データの欠落が疑われます。")
            print(f"  → input\\opening_{year}.json を確認してください。")
        else:
            print("  入力データに不正な値があります。上のメッセージを確認してください。")
        return 2

    total = sum((report.g(r, "income") for r in results.values()), Decimal(0))
    for cur, r in sorted(results.items(), key=lambda kv: -report.g(kv[1], "income")):
        print(f"      {cur:<6} 所得金額 {report.g(r,'income'):>14,} 円"
              f"   年末残高 {report._qty(report.g(r,'closing_quantity'))}")
    print(f"      {'合計':<6} {total:>19,} 円")

    # ---- 3. 出力 ----
    print("\n[3/4] ファイルを出力中 ...")
    xlsx_path = os.path.join(args.output, f"暗号資産の計算書_{year}.xlsx")
    html_path = os.path.join(args.output, f"レポート_{year}.html")
    json_path = os.path.join(args.output, f"繰越残高_{year}.json")

    try:
        warnings += report.write_kokuzei_xlsx(
            results, trades, margins, year, args.name, TEMPLATE, xlsx_path)
        print(f"      提出用 : {xlsx_path}")
    except FileNotFoundError as ex:
        print(f"      xlsx出力をスキップ: {ex}")
        warnings.append({"file": "-", "reason": f"xlsx未出力: {ex}"})

    absorption = Decimal(args.absorption) if args.absorption else None
    report.write_html_report(results, trades, margins, warnings, year,
                             args.name, html_path, absorption)
    print(f"      確認用 : {html_path}")

    report.write_carryover_json(results, year, json_path)
    print(f"      繰越用 : {json_path}")

    # ---- 4. 警告 ----
    print("\n[4/4] 確認事項")
    if warnings:
        print(f"      ⚠ {len(warnings)} 件あります。レポートHTMLの末尾を確認してください。")
        for w in warnings[:8]:
            print(f"        - {w.get('file','-')}: {w.get('reason','')[:70]}")
        if len(warnings) > 8:
            print(f"        - ほか {len(warnings)-8} 件")
    else:
        print("      なし。全ての行を計算対象として取り込みました。")

    print("\n" + "-" * 66)
    print(" 完了しました。")
    print(" ・提出用xlsx は Excel で開くと数式が再計算されます（開いて保存してください）")
    print(f" ・翌年は 繰越残高_{year}.json を input\\opening_{year+1}.json にコピーします")
    print("-" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
