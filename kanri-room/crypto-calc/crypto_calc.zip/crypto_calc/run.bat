@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo.
py crypto_calc.py %*
echo.
if errorlevel 1 (
  echo *** エラーが発生しました。上の内容を確認してください。 ***
) else (
  echo 出力先: %~dp0output
  start "" "%~dp0output"
)
echo.
pause