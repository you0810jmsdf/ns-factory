"""
取引所別CSVパーサ

各取引所のCSVを読み込み、calc.py が扱える共通形式（Trade / MarginResult）へ変換する。

対応取引所:
  - メルコイン（株式会社メルコイン / メルカリ）… 月次CSV × 12ファイル
  - GMOコイン … 年間取引報告書CSV 1ファイル（現物＋暗号資産FX）
  - OKJ（オーケーコイン・ジャパン）… 年間取引報告書がPDFのみのため手入力JSON

作成: 2026-08-21 監理幕僚
"""

from __future__ import annotations

import csv
import glob
import json
import os
import re
from decimal import Decimal
from typing import Iterable

from calc import Trade, MarginResult, OpeningBalance


# ---------------------------------------------------------------------------
# 共通ユーティリティ
# ---------------------------------------------------------------------------

def _dec(value) -> Decimal:
    """文字列を Decimal に変換する。空欄・None・カンマ区切りに耐える。"""
    if value is None:
        return Decimal(0)
    s = str(value).strip().replace(",", "").replace("¥", "").replace("円", "")
    if s == "" or s == "-":
        return Decimal(0)
    try:
        return Decimal(s)
    except Exception:
        return Decimal(0)


def _norm_date(value: str) -> str:
    """'2025/1/7 09:15:13' や '2025/01/03 13:00' を 'YYYY-MM-DD' に正規化する。"""
    s = str(value).strip()
    m = re.match(r"(\d{4})[/-](\d{1,2})[/-](\d{1,2})", s)
    if not m:
        return ""
    return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"


def _year_of(date_str: str) -> int | None:
    if len(date_str) >= 4 and date_str[:4].isdigit():
        return int(date_str[:4])
    return None


def _base_currency(pair_or_symbol: str) -> str:
    """'BTC/JPY' → 'BTC'、'BTC' → 'BTC' に正規化する。"""
    s = str(pair_or_symbol).strip().upper()
    if "/" in s:
        return s.split("/")[0]
    return s


class ParseWarning(dict):
    """パース時に読み飛ばした行や注意事項を記録するための入れ物。"""


# ---------------------------------------------------------------------------
# メルコイン（メルカリ）
# ---------------------------------------------------------------------------

# 月次CSVの末尾には「作成基準日時」「月末残高」等のメタ行が入る。
# 取引日時が空の行はすべてメタ行として読み飛ばす。
MERCOIN_TRADE_KINDS = {"購入": "buy", "売却": "sell"}
MERCOIN_IGNORE_KINDS = {"入金", "出金"}  # 日本円の入出金。損益に影響しない


def parse_mercoin(csv_paths: Iterable[str], year: int) -> tuple[list[Trade], list[dict]]:
    """
    メルコインの月次CSVを読み込む。

    列: 取引日時,取引種別,取引形態,通貨ペア,増加通貨名,増加数量,減少通貨名,減少数量,
        約定金額,約定価格,手数料通貨,手数料数量,登録番号,社名,備考
    文字コード: UTF-8（BOMなし）

    取引種別と数量の対応:
      購入 … 増加通貨名=暗号資産 / 増加数量=取得数量、減少数量=支払円
      売却 … 減少通貨名=暗号資産 / 減少数量=売却数量、増加数量=受取円

    戻り値: (Trade のリスト, 警告のリスト)
    """
    trades: list[Trade] = []
    warnings: list[dict] = []

    for path in sorted(csv_paths):
        if not os.path.exists(path):
            warnings.append({"file": path, "reason": "ファイルが存在しない"})
            continue

        with open(path, encoding="utf-8-sig", newline="") as fh:
            for lineno, row in enumerate(csv.DictReader(fh), start=2):
                raw_dt = (row.get("取引日時") or "").strip()
                if not raw_dt:
                    continue  # メタ行（作成基準日時・月末残高など）

                date = _norm_date(raw_dt)
                if _year_of(date) != year:
                    continue

                kind_jp = (row.get("取引種別") or "").strip()
                if kind_jp in MERCOIN_IGNORE_KINDS:
                    continue

                if kind_jp not in MERCOIN_TRADE_KINDS:
                    # 「受取」など想定外の種別。損益に影響しうるので必ず報告する。
                    warnings.append({
                        "file": os.path.basename(path), "line": lineno,
                        "reason": f"未対応の取引種別『{kind_jp}』のため読み飛ばした。手動確認が必要",
                        "row": {k: v for k, v in row.items() if str(v).strip()},
                    })
                    continue

                kind = MERCOIN_TRADE_KINDS[kind_jp]
                amount = _dec(row.get("約定金額"))

                if kind == "buy":
                    currency = _base_currency(row.get("増加通貨名") or row.get("通貨ペア"))
                    quantity = _dec(row.get("増加数量"))
                else:
                    currency = _base_currency(row.get("減少通貨名") or row.get("通貨ペア"))
                    quantity = _dec(row.get("減少数量"))

                if currency in ("", "JPY") or quantity <= 0:
                    warnings.append({
                        "file": os.path.basename(path), "line": lineno,
                        "reason": "通貨名または数量を特定できず読み飛ばした",
                        "row": {k: v for k, v in row.items() if str(v).strip()},
                    })
                    continue

                # メルコインは手数料をスプレッドに内包し、手数料列は通常空。
                fee = _dec(row.get("手数料数量")) if (row.get("手数料通貨") or "").strip() == "JPY" else Decimal(0)

                trades.append(Trade(
                    date=date, currency=currency, kind=kind,
                    quantity=quantity, amount_jpy=amount, fee_jpy=fee,
                    source="メルコイン",
                ))

    return trades, warnings


# ---------------------------------------------------------------------------
# GMOコイン
# ---------------------------------------------------------------------------

# 精算区分の分類
GMO_SPOT_KINDS = {"販売所取引", "取引所現物取引"}          # 現物取引
GMO_SPOT_REFUND = {"取引所現物 取引手数料返金"}            # 手数料返金（必要経費のマイナス）
GMO_FX_TRADE = "暗号資産FX取引"                            # 証拠金取引
GMO_FX_FEE = "暗号資産FXレバレッジ手数料"                  # レバレッジ手数料
GMO_IGNORE_KINDS = {"日本円入出金"}                        # 円の入出金。損益に影響しない


def parse_gmo(csv_path: str, year: int) -> tuple[list[Trade], list[MarginResult], list[dict]]:
    """
    GMOコインの年間取引報告書CSVを読み込む。

    列: 日時,精算区分,日本円受渡金額,注文ID,約定ID,建玉ID,銘柄名,注文タイプ,取引区分,
        売買区分,執行条件,約定数量,約定レート,約定金額,注文手数料,レバレッジ手数料,
        入出金区分,入出金金額,授受区分,数量,送付手数料,送付先/送付元,トランザクションID
    文字コード: UTF-8（BOM付き）→ utf-8-sig で読む

    現物（販売所取引・取引所現物取引）:
      買 … 約定数量 / 約定金額
      売 … 約定数量 / 売却価額は「日本円受渡金額」（注文手数料を差引いた後の実受取額）を採用する。
           ※国税庁の計算書と一致させるための扱い。手数料を別途必要経費に計上すると二重控除になる。

    暗号資産FX（証拠金取引）:
      損益 = 「暗号資産FX取引」かつ 取引区分=決済 の行の 日本円受渡金額 の合計
             ＋「暗号資産FXレバレッジ手数料」の 日本円受渡金額 の合計（通常マイナス）
      新規建玉の行は損益ゼロなので集計対象外。

    戻り値: (現物Tradeのリスト, 証拠金取引MarginResultのリスト, 警告のリスト)
    """
    trades: list[Trade] = []
    warnings: list[dict] = []
    # 証拠金取引は通貨ごとに差益・差損を分けて集計する
    margin_pl: dict[str, Decimal] = {}

    if not os.path.exists(csv_path):
        return [], [], [{"file": csv_path, "reason": "ファイルが存在しない"}]

    with open(csv_path, encoding="utf-8-sig", newline="") as fh:
        for lineno, row in enumerate(csv.DictReader(fh), start=2):
            date = _norm_date(row.get("日時") or "")
            if _year_of(date) != year:
                continue

            kbn = (row.get("精算区分") or "").strip()

            if kbn in GMO_IGNORE_KINDS:
                continue

            # ---- 証拠金取引（暗号資産FX） ----
            if kbn == GMO_FX_TRADE:
                if (row.get("取引区分") or "").strip() == "決済":
                    cur = _base_currency(row.get("銘柄名"))
                    margin_pl[cur] = margin_pl.get(cur, Decimal(0)) + _dec(row.get("日本円受渡金額"))
                continue

            if kbn == GMO_FX_FEE:
                cur = _base_currency(row.get("銘柄名"))
                # レバレッジ手数料列と受渡金額列の両方に同額が入る。受渡金額を優先。
                fee = _dec(row.get("日本円受渡金額")) or _dec(row.get("レバレッジ手数料"))
                margin_pl[cur] = margin_pl.get(cur, Decimal(0)) + fee
                continue

            # ---- 現物取引 ----
            if kbn in GMO_SPOT_KINDS:
                cur = _base_currency(row.get("銘柄名"))
                side = (row.get("売買区分") or "").strip()
                quantity = _dec(row.get("約定数量"))
                if cur in ("", "JPY") or quantity <= 0 or side not in ("買", "売"):
                    warnings.append({
                        "file": os.path.basename(csv_path), "line": lineno,
                        "reason": "現物取引だが通貨・数量・売買区分を特定できず読み飛ばした",
                        "row": {k: v for k, v in row.items() if str(v).strip()},
                    })
                    continue

                if side == "買":
                    # 取得価額は約定金額（手数料は取得価額に含めず、様式どおり別扱い）
                    amount = _dec(row.get("約定金額"))
                    trades.append(Trade(
                        date=date, currency=cur, kind="buy",
                        quantity=quantity, amount_jpy=amount, fee_jpy=Decimal(0),
                        source="GMOコイン",
                    ))
                else:
                    # 売却価額は手数料差引後の実受取額（日本円受渡金額）
                    receipt = _dec(row.get("日本円受渡金額"))
                    amount = receipt if receipt > 0 else _dec(row.get("約定金額"))
                    trades.append(Trade(
                        date=date, currency=cur, kind="sell",
                        quantity=quantity, amount_jpy=amount, fee_jpy=Decimal(0),
                        source="GMOコイン",
                    ))
                continue

            if kbn in GMO_SPOT_REFUND:
                # 手数料返金。金額が小さく様式上の欄がないため、警告として可視化するに留める。
                warnings.append({
                    "file": os.path.basename(csv_path), "line": lineno,
                    "reason": f"『{kbn}』は自動計上していない。金額 {row.get('日本円受渡金額')} 円を手動確認すること",
                    "row": {k: v for k, v in row.items() if str(v).strip()},
                })
                continue

            warnings.append({
                "file": os.path.basename(csv_path), "line": lineno,
                "reason": f"未対応の精算区分『{kbn}』のため読み飛ばした。手動確認が必要",
                "row": {k: v for k, v in row.items() if str(v).strip()},
            })

    margins = [
        MarginResult(
            currency=cur,
            profit_jpy=pl if pl > 0 else Decimal(0),
            loss_jpy=-pl if pl < 0 else Decimal(0),
        )
        for cur, pl in sorted(margin_pl.items())
    ]

    return trades, margins, warnings


# ---------------------------------------------------------------------------
# OKJ（オーケーコイン・ジャパン）… 手入力JSON
# ---------------------------------------------------------------------------

def parse_okj_manual(json_path: str, year: int) -> tuple[list[Trade], list[dict]]:
    """
    OKJは年間取引報告書がPDFでしか提供されないため、手入力したJSONから読み込む。

    JSONの形式（input/okj_YYYY.json）:
    {
      "year": 2025,
      "source": "OKJ年間取引報告書_YYYY.pdf",
      "trades": [
        {"currency": "BTC", "kind": "buy",  "quantity": "0.87654321", "amount_jpy": "7654321.09"},
        {"currency": "BTC", "kind": "sell", "quantity": "0.55555555",  "amount_jpy": "6000000",
         "fee_jpy": "1234.56"}
      ]
    }

    ※ 年間取引報告書は購入・売却が通貨ごとに合計値で記載されるため、
       1通貨あたり buy 1行・sell 1行にまとめて入力すればよい。
    """
    trades: list[Trade] = []
    warnings: list[dict] = []

    if not os.path.exists(json_path):
        warnings.append({
            "file": os.path.basename(json_path),
            "reason": "OKJの手入力JSONが無い。OKJ年間取引報告書PDFから転記が必要",
        })
        return [], warnings

    with open(json_path, encoding="utf-8") as fh:
        data = json.load(fh)

    if int(data.get("year", year)) != year:
        warnings.append({
            "file": os.path.basename(json_path),
            "reason": f"JSONのyear={data.get('year')} が対象年 {year} と一致しない",
        })

    for i, item in enumerate(data.get("trades", []), start=1):
        kind = str(item.get("kind", "")).strip().lower()
        if kind not in ("buy", "sell"):
            warnings.append({
                "file": os.path.basename(json_path), "line": i,
                "reason": f"kind は buy か sell のみ。『{item.get('kind')}』は読み飛ばした",
            })
            continue
        trades.append(Trade(
            date=f"{year}-12-31",  # 年間合計のため便宜上の日付
            currency=_base_currency(item.get("currency", "")),
            kind=kind,
            quantity=_dec(item.get("quantity")),
            amount_jpy=_dec(item.get("amount_jpy")),
            fee_jpy=_dec(item.get("fee_jpy")),
            source="OKJ",
        ))

    return trades, warnings


# ---------------------------------------------------------------------------
# 前年繰越（年始残高）
# ---------------------------------------------------------------------------

def load_openings(json_path: str) -> tuple[list[OpeningBalance], list[dict]]:
    """
    前年の output/繰越残高_YYYY.json、または手入力の年始残高JSONを読み込む。

    形式:
    {
      "year": 2025,
      "balances": [
        {"currency": "BTC", "quantity": "1.23456789", "amount_jpy": "9876543.21"}
      ]
    }

    ファイルが無い場合は空リストを返す（初年度＝年始残高ゼロとして扱う）。
    """
    warnings: list[dict] = []
    if not os.path.exists(json_path):
        warnings.append({
            "file": os.path.basename(json_path),
            "reason": "年始残高ファイルが無い。全通貨の年始残高をゼロとして計算した。"
                      "前年から保有がある場合は必ず用意すること（総平均法は繰越が命）",
        })
        return [], warnings

    with open(json_path, encoding="utf-8") as fh:
        data = json.load(fh)

    openings = [
        OpeningBalance(
            currency=_base_currency(b.get("currency", "")),
            quantity=_dec(b.get("quantity")),
            amount_jpy=_dec(b.get("amount_jpy")),
        )
        for b in data.get("balances", [])
    ]
    return openings, warnings


# ---------------------------------------------------------------------------
# 入力フォルダの自動判別
# ---------------------------------------------------------------------------

def collect_all(input_dir: str, year: int):
    """
    input フォルダを走査し、3社ぶんのデータをまとめて読み込む。

    想定ファイル名:
      メルコイン … mercoin_*.csv もしくは 2025*.csv（月次12ファイル）
      GMOコイン  … gmo_*.csv（年間取引報告書）
      OKJ        … okj_YYYY.json（PDFからの手入力）
      年始残高   … opening_YYYY.json

    戻り値: (trades, margins, openings, warnings)
    """
    warnings: list[dict] = []

    mercoin_files = sorted(
        glob.glob(os.path.join(input_dir, "mercoin_*.csv"))
        + glob.glob(os.path.join(input_dir, f"{year}[01][0-9].csv"))
    )
    trades_m, w = parse_mercoin(mercoin_files, year)
    warnings += w
    if not mercoin_files:
        warnings.append({"file": "-", "reason": "メルコインのCSVが1件も見つからなかった"})

    trades_g: list[Trade] = []
    margins: list[MarginResult] = []
    gmo_files = sorted(glob.glob(os.path.join(input_dir, "gmo_*.csv")))
    if not gmo_files:
        warnings.append({"file": "-", "reason": "GMOコインのCSVが見つからなかった"})
    for path in gmo_files:
        t, m, w = parse_gmo(path, year)
        trades_g += t
        margins += m
        warnings += w

    trades_o, w = parse_okj_manual(os.path.join(input_dir, f"okj_{year}.json"), year)
    warnings += w

    openings, w = load_openings(os.path.join(input_dir, f"opening_{year}.json"))
    warnings += w

    return trades_m + trades_g + trades_o, margins, openings, warnings
