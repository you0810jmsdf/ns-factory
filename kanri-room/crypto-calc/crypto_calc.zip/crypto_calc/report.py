"""
出力モジュール

  1) 国税庁「暗号資産の計算書（総平均法用）」様式の xlsx を生成（提出用）
  2) 見やすい HTML レポートを生成（確認用）
  3) 翌年へ引き継ぐ繰越残高 JSON を生成

xlsx はテンプレート `templates/暗号資産の計算書_総平均法_template.xlsx` に
値を流し込む方式。テンプレートには国税庁様式の数式がそのまま残してあるため、
Excel で開いた時点で (E) 総平均単価・(G) 売却原価・所得金額が自動計算される。

作成: 2026-08-21 監理幕僚
"""

from __future__ import annotations

import html
import json
import os
from decimal import Decimal, ROUND_DOWN

import openpyxl


# ---------------------------------------------------------------------------
# calc.py の CurrencyResult から値を取り出すための緩衝層
# ---------------------------------------------------------------------------

# calc.CurrencyResult の属性名との対応表。
#
# ⚠ 命名が紛らわしいので注意すること:
#     income_jpy          … 収入金額（売却価額＋証拠金差益）であって「所得金額」ではない
#     expenses_jpy        … 必要経費（売却原価＋手数料等＋証拠金差損）
#     taxable_income_jpy  … 所得金額（収入金額 − 必要経費・1円未満切捨て後）← これが最終値
_FIELD_ALIASES = {
    "opening_quantity":   ("A",),                  # (A) 年始残高 数量
    "opening_amount":     ("B",),                  # (B) 年始残高 金額
    "purchase_quantity":  ("C",),                  # (C) 購入等 数量
    "purchase_amount":    ("D",),                  # (D) 購入等 金額
    "average_unit_price": ("E",),                  # (E) 総平均単価
    "sold_quantity":      ("F",),                  # (F) 売却 数量
    "cost_of_sales":      ("G",),                  # (G) 売却原価
    "closing_quantity":   ("H",),                  # (H) 年末残高 数量
    "closing_amount":     ("I",),                  # (I) 年末残高 金額
    "fees":               ("sell_fee_jpy",),       # 手数料等
    "revenue":            ("income_jpy",),         # 収入金額
    "expenses":           ("expenses_jpy",),       # 必要経費
    "income":             ("taxable_income_jpy",), # 所得金額（最終値）
}


def g(result, key: str) -> Decimal:
    """CurrencyResult から値を取り出す。calc.py 側の属性名変更に一箇所で追随できるようにする。"""
    for name in _FIELD_ALIASES.get(key, (key,)):
        if hasattr(result, name):
            v = getattr(result, name)
            return v if isinstance(v, Decimal) else Decimal(str(v))
    # CurrencyResult は slots=True のため vars() が使えない
    actual = sorted(getattr(type(result), "__slots__", ()) or dir(result))
    raise AttributeError(
        f"CurrencyResult に '{key}' に相当する属性がありません。"
        f"想定した属性名: {_FIELD_ALIASES.get(key)} / 実際: {actual}"
    )


def _yen(d: Decimal) -> str:
    """円表示（3桁区切り・小数は切り捨てず2位まで表示）。"""
    if d == d.to_integral_value():
        return f"{int(d):,}"
    return f"{d.quantize(Decimal('0.01')):,}"


def _qty(d: Decimal) -> str:
    """数量表示。Decimal の高精度演算による末尾ノイズを丸めてから表示する。"""
    return format(d.quantize(Decimal("1E-12")).normalize(), "f")


def _floor_yen(d: Decimal) -> Decimal:
    """1円未満切捨て。"""
    return d.quantize(Decimal("1"), rounding=ROUND_DOWN)


# ---------------------------------------------------------------------------
# 1) 国税庁様式 xlsx
# ---------------------------------------------------------------------------

SHEET_NAMES = ["計算書①", "計算書②", "計算書③", "計算書④", "計算書⑤",
               "計算書⑥", "計算書⑦", "計算書⑧", "計算書⑨", "計算書⑩"]

# 取引所別の内訳を書き込む行（様式上は最大5行）
EXCHANGE_ROWS = (12, 13, 14, 15, 16)


def write_kokuzei_xlsx(results, trades, margins, year: int, taxpayer_name: str,
                       template_path: str, out_path: str) -> list[dict]:
    """
    国税庁様式の xlsx を生成する。

    results: {通貨コード: CurrencyResult}
    trades:  Trade のリスト（取引所別の内訳を作るために使う）
    margins: MarginResult のリスト（信用・証拠金の差益/差損欄に入れる）
    戻り値:  警告のリスト
    """
    warnings: list[dict] = []
    margin_by_cur = {m.currency: m for m in (margins or [])}

    if not os.path.exists(template_path):
        raise FileNotFoundError(
            f"テンプレートが見つかりません: {template_path}\n"
            "国税庁様式のxlsxを templates/ に置いてください。"
        )

    wb = openpyxl.load_workbook(template_path)  # 数式を保持したまま読む

    # 所得金額の大きい順に 計算書①から割り当てる（重要な通貨が先頭に来るように）
    ordered = sorted(results.items(), key=lambda kv: -g(kv[1], "income"))

    if len(ordered) > len(SHEET_NAMES):
        overflow = [c for c, _ in ordered[len(SHEET_NAMES):]]
        warnings.append({
            "file": os.path.basename(out_path),
            "reason": f"様式は10通貨までのため {', '.join(overflow)} を書き込めなかった。"
                      "別ファイルに分けて手入力すること",
        })

    for idx, (currency, res) in enumerate(ordered[:len(SHEET_NAMES)]):
        ws = wb[SHEET_NAMES[idx]]

        ws["O3"] = year - 2018          # 西暦→令和（2025→令和7）
        ws["AS5"] = taxpayer_name
        ws["U6"] = currency

        # --- 取引所別の購入・売却を集計して 12〜16 行に書く ---
        by_source: dict[str, dict[str, Decimal]] = {}
        for t in trades:
            if t.currency != currency:
                continue
            b = by_source.setdefault(t.source, {
                "buy_q": Decimal(0), "buy_a": Decimal(0),
                "sell_q": Decimal(0), "sell_a": Decimal(0),
            })
            if t.kind == "buy":
                b["buy_q"] += t.quantity
                b["buy_a"] += t.amount_jpy
            else:
                b["sell_q"] += t.quantity
                b["sell_a"] += t.amount_jpy

        sources = sorted(by_source.keys())
        if len(sources) > len(EXCHANGE_ROWS):
            warnings.append({
                "file": os.path.basename(out_path),
                "reason": f"{currency}: 取引所が{len(sources)}社あり様式の5行に収まらない",
            })

        for row, src in zip(EXCHANGE_ROWS, sources):
            b = by_source[src]
            ws[f"C{row}"] = src
            ws[f"U{row}"] = float(b["buy_q"]) if b["buy_q"] else None
            ws[f"AD{row}"] = float(b["buy_a"]) if b["buy_a"] else None
            ws[f"AM{row}"] = float(b["sell_q"]) if b["sell_q"] else None
            ws[f"AV{row}"] = float(b["sell_a"]) if b["sell_a"] else None

        # --- (A)(B) 年始残高 ---
        ws["N41"] = float(g(res, "opening_quantity"))
        ws["N42"] = float(g(res, "opening_amount"))

        # --- 手数料等・信用/証拠金 ---
        fees = g(res, "fees")
        ws["AD50"] = float(fees) if fees else None

        m = margin_by_cur.get(currency)
        if m is not None:
            ws["L50"] = float(m.profit_jpy) if m.profit_jpy else None
            ws["AM50"] = float(m.loss_jpy) if m.loss_jpy else None

        # (C)(D)(E)(F)(G)(H)(I)・収入金額・必要経費・所得金額はテンプレートの数式が計算する

    wb.save(out_path)
    return warnings


# ---------------------------------------------------------------------------
# 2) HTML レポート
# ---------------------------------------------------------------------------

_CSS = """
:root{--bg:#fff;--fg:#1a1a1a;--muted:#666;--line:#dcdcdc;--accent:#1f5c8b;
      --warn-bg:#fff7e6;--warn-line:#e0a800;--pos:#0a7d3f;--neg:#b3261e;--head:#f4f6f8;}
*{box-sizing:border-box}
body{margin:0;padding:32px 20px;background:var(--bg);color:var(--fg);
     font-family:"Meiryo","Yu Gothic","Hiragino Kaku Gothic ProN",sans-serif;
     font-size:14px;line-height:1.7;}
.wrap{max-width:1080px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px;border-bottom:3px solid var(--accent);padding-bottom:10px}
h2{font-size:17px;margin:34px 0 10px;padding-left:10px;border-left:5px solid var(--accent)}
.sub{color:var(--muted);font-size:13px;margin:0 0 24px}
table{border-collapse:collapse;width:100%;margin:10px 0 18px;font-size:13px}
th,td{border:1px solid var(--line);padding:7px 10px;text-align:right;vertical-align:top}
th{background:var(--head);text-align:center;font-weight:600;white-space:nowrap}
td.l,th.l{text-align:left}
tbody tr:nth-child(even){background:#fafbfc}
.num{font-variant-numeric:tabular-nums;font-feature-settings:"tnum"}
.total{font-weight:700;background:#eef4f9 !important}
.pos{color:var(--pos)} .neg{color:var(--neg)}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
.card{border:1px solid var(--line);border-radius:8px;padding:14px 16px}
.card h3{margin:0 0 8px;font-size:16px;color:var(--accent);
         border-bottom:1px solid var(--line);padding-bottom:6px}
.card dl{display:grid;grid-template-columns:auto 1fr;gap:3px 12px;margin:0;font-size:13px}
.card dt{color:var(--muted);white-space:nowrap}
.card dd{margin:0;text-align:right;font-variant-numeric:tabular-nums}
.card .hl{font-weight:700;font-size:15px}
.warn{background:var(--warn-bg);border-left:5px solid var(--warn-line);
      padding:12px 16px;margin:14px 0;border-radius:0 6px 6px 0}
.warn h2{margin-top:0;border:none;padding-left:0;color:#8a6d00}
.note{color:var(--muted);font-size:12px;margin-top:6px}
code{background:#f2f3f5;padding:1px 5px;border-radius:3px;font-size:12px}
@media print{body{padding:0}.card{break-inside:avoid}}
"""


def write_html_report(results, trades, margins, warnings, year: int,
                      taxpayer_name: str, out_path: str,
                      absorption_capacity: Decimal | None = None) -> None:
    """
    確認用のHTMLレポートを書き出す。

    absorption_capacity: その年の「税ゼロ吸収枠」（所得控除＋事業赤字等）。
                         指定すると所得金額との比較を表示する。
    """
    e = html.escape
    total_income = sum((g(r, "income") for r in results.values()), Decimal(0))
    total_margin = sum((m.profit_jpy - m.loss_jpy for m in margins), Decimal(0))

    parts: list[str] = []
    parts.append(f"""<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>暗号資産 計算レポート {year}年分</title><style>{_CSS}</style></head><body><div class="wrap">
<h1>暗号資産 計算レポート　{year}年分（令和{year-2018}年分）</h1>
<p class="sub">氏名: {e(taxpayer_name)}　／　評価方法: 総平均法　／
この数値は<strong>確認用</strong>です。提出用は同時出力の xlsx（国税庁様式）を使ってください。</p>""")

    # ---- サマリー ----
    parts.append('<h2>サマリー</h2><table><tbody>')
    parts.append(f'<tr><th class="l">現物取引の所得金額 合計</th>'
                 f'<td class="num">{_yen(total_income)} 円</td></tr>')
    if margins:
        cls = "pos" if total_margin >= 0 else "neg"
        parts.append(f'<tr><th class="l">証拠金取引（暗号資産FX）損益</th>'
                     f'<td class="num {cls}">{_yen(total_margin)} 円</td></tr>')
    parts.append(f'<tr class="total"><th class="l">雑所得（暗号資産）合計</th>'
                 f'<td class="num">{_yen(total_income)} 円</td></tr>')
    parts.append('</tbody></table>')
    parts.append('<p class="note">※ 証拠金取引の損益は上表の「所得金額 合計」に'
                 '既に含まれています（暗号資産の証拠金取引は現物と同じ総合課税の雑所得。'
                 'FXの申告分離課税20.315%は適用されません）。</p>')

    if absorption_capacity is not None:
        remain = absorption_capacity - total_income
        cls = "pos" if remain >= 0 else "neg"
        msg = (f"あと {_yen(remain)} 円の利確まで所得税ゼロの見込み"
               if remain >= 0 else
               f"吸収枠を {_yen(-remain)} 円 超過。課税が発生する見込み")
        parts.append(f'<h2>税ゼロ吸収枠との比較</h2><table><tbody>'
                     f'<tr><th class="l">吸収枠（所得控除＋事業等の赤字）</th>'
                     f'<td class="num">{_yen(absorption_capacity)} 円</td></tr>'
                     f'<tr><th class="l">暗号資産の所得金額</th>'
                     f'<td class="num">{_yen(total_income)} 円</td></tr>'
                     f'<tr class="total"><th class="l">残り</th>'
                     f'<td class="num {cls}">{_yen(remain)} 円</td></tr></tbody></table>'
                     f'<p class="note">{msg}。'
                     'あくまで暗号資産のみの概算です。国民健康保険料・住民税・'
                     '不動産の譲渡所得は含みません。</p>')

    # ---- 通貨別カード ----
    parts.append('<h2>通貨別の計算過程（総平均法）</h2><div class="cards">')
    for currency, r in sorted(results.items(), key=lambda kv: -g(kv[1], "income")):
        inc = g(r, "income")
        cls = "pos" if inc >= 0 else "neg"
        parts.append(f"""<div class="card"><h3>{e(currency)}</h3><dl>
<dt>(A) 年始残高 数量</dt><dd>{_qty(g(r,'opening_quantity'))}</dd>
<dt>(B) 年始残高 金額</dt><dd>{_yen(g(r,'opening_amount'))} 円</dd>
<dt>(C) 購入等 数量</dt><dd>{_qty(g(r,'purchase_quantity'))}</dd>
<dt>(D) 購入等 金額</dt><dd>{_yen(g(r,'purchase_amount'))} 円</dd>
<dt>(E) 総平均単価</dt><dd>{_yen(g(r,'average_unit_price'))} 円</dd>
<dt>(F) 売却 数量</dt><dd>{_qty(g(r,'sold_quantity'))}</dd>
<dt>(G) 売却原価</dt><dd>{_yen(g(r,'cost_of_sales'))} 円</dd>
<dt>(H) 年末残高 数量</dt><dd>{_qty(g(r,'closing_quantity'))}</dd>
<dt>(I) 年末残高 金額</dt><dd>{_yen(g(r,'closing_amount'))} 円</dd>
<dt>収入金額</dt><dd>{_yen(g(r,'revenue'))} 円</dd>
<dt>必要経費</dt><dd>{_yen(g(r,'expenses'))} 円</dd>
<dt class="hl">所得金額</dt><dd class="hl {cls}">{_yen(inc)} 円</dd>
</dl></div>""")
    parts.append('</div>')
    parts.append('<p class="note">(E) 総平均単価 =（B＋D）÷（A＋C）　／　'
                 '(G) 売却原価 = E×F　／　(I) 年末残高金額 =（B＋D）−G　'
                 '…… (H)(I) がそのまま翌年の (A)(B) になります。</p>')

    # ---- 取引所別の内訳 ----
    parts.append('<h2>取引所別の内訳</h2><table><thead><tr>'
                 '<th class="l">取引所</th><th class="l">通貨</th>'
                 '<th>購入 数量</th><th>購入 金額</th>'
                 '<th>売却 数量</th><th>売却 金額</th></tr></thead><tbody>')
    agg: dict[tuple[str, str], dict[str, Decimal]] = {}
    for t in trades:
        k = (t.source, t.currency)
        a = agg.setdefault(k, {"bq": Decimal(0), "ba": Decimal(0),
                               "sq": Decimal(0), "sa": Decimal(0)})
        if t.kind == "buy":
            a["bq"] += t.quantity; a["ba"] += t.amount_jpy
        else:
            a["sq"] += t.quantity; a["sa"] += t.amount_jpy
    for (src, cur), a in sorted(agg.items()):
        parts.append(f'<tr><td class="l">{e(src)}</td><td class="l">{e(cur)}</td>'
                     f'<td class="num">{_qty(a["bq"])}</td><td class="num">{_yen(a["ba"])}</td>'
                     f'<td class="num">{_qty(a["sq"])}</td><td class="num">{_yen(a["sa"])}</td></tr>')
    parts.append('</tbody></table>')

    # ---- 証拠金取引 ----
    if margins:
        parts.append('<h2>証拠金取引（暗号資産FX）</h2><table><thead><tr>'
                     '<th class="l">銘柄</th><th>差益</th><th>差損</th><th>純損益</th>'
                     '</tr></thead><tbody>')
        for m in margins:
            net = m.profit_jpy - m.loss_jpy
            cls = "pos" if net >= 0 else "neg"
            parts.append(f'<tr><td class="l">{e(m.currency)}</td>'
                         f'<td class="num">{_yen(m.profit_jpy)}</td>'
                         f'<td class="num">{_yen(m.loss_jpy)}</td>'
                         f'<td class="num {cls}">{_yen(net)}</td></tr>')
        parts.append('</tbody></table>')
        parts.append('<p class="note">差益＝決済益の合計、差損＝決済損とレバレッジ手数料の合計。'
                     '国税庁様式では「信用・証拠金（差益）」「同（差損）」欄に入ります。</p>')

    # ---- 警告 ----
    if warnings:
        parts.append('<div class="warn"><h2>⚠ 確認が必要な項目'
                     f'（{len(warnings)}件）</h2><table><thead><tr>'
                     '<th class="l">ファイル</th><th>行</th><th class="l">内容</th>'
                     '</tr></thead><tbody>')
        for w in warnings:
            parts.append(f'<tr><td class="l">{e(str(w.get("file","-")))}</td>'
                         f'<td class="num">{e(str(w.get("line","-")))}</td>'
                         f'<td class="l">{e(str(w.get("reason","")))}</td></tr>')
        parts.append('</tbody></table><p class="note">'
                     '読み飛ばした行がある場合、所得金額が過少になっている可能性があります。'
                     '必ず原本と突き合わせてください。</p></div>')
    else:
        parts.append('<h2>確認が必要な項目</h2><p>ありません。'
                     '全ての行を計算対象として取り込みました。</p>')

    parts.append('</div></body></html>')

    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(parts))


# ---------------------------------------------------------------------------
# 3) 翌年繰越 JSON
# ---------------------------------------------------------------------------

def write_carryover_json(results, year: int, out_path: str) -> None:
    """
    年末残高 (H)(I) を翌年の年始残高 (A)(B) として使えるJSONで書き出す。
    翌年は このファイルを input/opening_{year+1}.json にコピーして使う。
    """
    data = {
        "year": year + 1,
        "note": f"{year}年末残高。翌年の年始残高(A)(B)として使う。"
                f"input/opening_{year+1}.json にコピーすること",
        "balances": [
            {
                "currency": cur,
                # Decimal の高精度演算による末尾ノイズを落とす。
                # 数量は暗号資産の最小単位（BTCで8桁）に十分な12桁、金額は2桁で丸める。
                "quantity": format(
                    g(r, "closing_quantity").quantize(Decimal("1E-12")).normalize(), "f"),
                "amount_jpy": format(
                    g(r, "closing_amount").quantize(Decimal("0.01")).normalize(), "f"),
            }
            for cur, r in sorted(results.items())
            if g(r, "closing_quantity") != 0 or g(r, "closing_amount") != 0
        ],
    }
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
