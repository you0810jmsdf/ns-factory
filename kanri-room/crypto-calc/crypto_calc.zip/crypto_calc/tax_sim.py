"""
税ゼロ吸収枠 ＆ 利確シミュレーター（所得税・住民税・国民健康保険税）

暗号資産をいくら利確すると、実際にいくら負担が増えるのかを試算する。
ブラウザ版（監理幕僚室の暗号資産 計算書ツール）と同一のロジック。
両者がずれていないことは tests/test_tax_sim.py で検証している。

使い方:
  py tax_sim.py --biz -1200000 --re -400000 --ded 2000000 --spouse 380000
  py tax_sim.py --biz -1200000 --re -400000 --ded 2000000 --sep 3400000 --step 500000

⚠ 免責: 概算である。実際の申告・納付額は税務署・市役所の計算が優先する。

作成: 2026-08-21 監理幕僚
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass

# --- 所得税の速算表（課税所得 → 税額）。復興特別所得税は別途 2.1% -------------
IT_BRACKETS = [
    ( 1_950_000, 0.05,         0),
    ( 3_300_000, 0.10,    97_500),
    ( 6_950_000, 0.20,   427_500),
    ( 9_000_000, 0.23,   636_000),
    (18_000_000, 0.33, 1_536_000),
    (40_000_000, 0.40, 2_796_000),
    (float("inf"), 0.45, 4_796_000),
]


def income_tax_of(taxable: float) -> int:
    """課税所得から所得税額を求める（千円未満切捨て）。"""
    t = int(max(0, taxable) // 1000) * 1000
    for cap, rate, ded in IT_BRACKETS:
        if t <= cap:
            return max(0, int(t * rate - ded))
    return 0


# --- 印西市 令和8年度 国民健康保険税 ------------------------------------------
# 出典: 印西市「国民健康保険税の賦課」（2026-08-21 取得）
# ⚠ 料率は毎年度改定される。年度が変わったら必ず市の公表値を確認して更新すること。
KOKUHO_BASIC_DEDUCTION = 430_000          # 旧ただし書き所得の算定に使う基礎控除
KOKUHO_PARTS = {
    # 名称:   (所得割率, 均等割/人, 平等割/世帯, 賦課限度額)
    "医療":   (0.0720, 24_000, 29_000, 670_000),
    "支援":   (0.0230, 11_500,      0, 260_000),
    "介護":   (0.0200, 14_000,      0, 170_000),   # 40〜64歳のみ
    "子育て": (0.0025,  1_730,      0,  30_000),   # 18歳未満は均等割が免除
}


def spouse_cap_of(total_income: float, base: int, is_resident: bool) -> int:
    """配偶者控除は本人の合計所得金額で逓減し、1,000万円超で消える。"""
    full = 330_000 if is_resident else 380_000
    cap = min(base, full)
    if total_income > 10_000_000:
        return 0
    if total_income > 9_500_000:
        return min(cap, 110_000 if is_resident else 130_000)
    if total_income > 9_000_000:
        return min(cap, 220_000 if is_resident else 260_000)
    return cap


@dataclass
class Params:
    """試算の前提。金額はすべて円。赤字はマイナスで渡す。"""
    biz: int = 0          # 事業所得
    re: int = 0           # 不動産所得
    other: int = 0        # その他の総合課税の所得（給与・年金など）
    sep: int = 0          # 分離長期譲渡所得（不動産の売却益・5年超）
    ded: int = 0          # 所得税の所得控除 合計
    ded_r: int | None = None   # 住民税の所得控除 合計（None なら所得税−15万で概算）
    spouse: int = 0       # うち配偶者（特別）控除
    members: int = 1      # 世帯の国保加入者数
    kaigo: int = 0        # うち40〜64歳
    children: int = 0     # うち18歳未満

    @property
    def deduction_resident(self) -> int:
        return self.ded_r if self.ded_r is not None else max(0, self.ded - 150_000)


@dataclass
class Result:
    gain: int
    total_income: float
    income_tax: int
    reconstruction: int
    resident_tax: int
    kokuho: int
    total: int


def simulate(p: Params, gain: int) -> Result:
    """
    暗号資産を gain 円だけ利確した場合の税・保険料を試算する。

    損益通算と所得控除の充当順序は租税特別措置法関係通達 31・32共-4 に従い
    「総所得金額 → 分離長期譲渡所得」の順とする。
    """
    sougou_raw = p.biz + p.re + p.other + gain
    sougou = max(0, sougou_raw)
    carry_loss = -sougou_raw if sougou_raw < 0 else 0   # 通算しきれない経常所得の赤字
    separate = max(0, p.sep - carry_loss)               # 赤字は分離長期からも控除できる
    total_income = sougou + separate

    def split(ded_total: int, is_resident: bool) -> tuple[float, float]:
        spouse_now = spouse_cap_of(total_income, p.spouse, is_resident)
        spouse_base = min(p.spouse, 330_000) if is_resident else p.spouse
        ded = max(0, ded_total - (spouse_base - spouse_now))
        to_sougou = min(ded, sougou)
        return sougou - to_sougou, max(0, separate - (ded - to_sougou))

    # 所得税・復興特別所得税
    tax_sougou, tax_sep = split(p.ded, False)
    income_tax = income_tax_of(tax_sougou) + int(int(tax_sep // 1000) * 1000 * 0.15)
    reconstruction = int(income_tax * 0.021)

    # 住民税（所得割＋均等割5,000円。均等割の非課税限度額は織り込んでいない）
    r_sougou, r_sep = split(p.deduction_resident, True)
    resident_tax = (
        int(int(r_sougou // 1000) * 1000 * 0.10)
        + int(int(r_sep // 1000) * 1000 * 0.05)
        + 5_000
    ) if total_income > 0 else 0

    # 国民健康保険税（所得控除はほぼ効かない。基礎控除43万のみ）
    base = max(0, total_income - KOKUHO_BASIC_DEDUCTION)
    people = {
        "医療": p.members, "支援": p.members,
        "介護": p.kaigo, "子育て": max(0, p.members - p.children),
    }
    kokuho = sum(
        min(cap, int(base * rate) + per * people[name] + house)
        for name, (rate, per, house, cap) in KOKUHO_PARTS.items()
    )

    return Result(gain, total_income, income_tax, reconstruction,
                  resident_tax, kokuho,
                  income_tax + reconstruction + resident_tax + kokuho)


def find_capacity(p: Params) -> int:
    """所得税がゼロで収まる利確額の上限（税ゼロ吸収枠）を二分探索で求める。"""
    if simulate(p, 0).income_tax > 0:
        return 0
    lo, hi = 0, 100_000_000
    if simulate(p, hi).income_tax == 0:
        return hi
    while hi - lo > 1000:
        mid = int((lo + hi) // 2 // 1000) * 1000
        if simulate(p, mid).income_tax == 0:
            lo = mid
        else:
            hi = mid
    return lo


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="税ゼロ吸収枠と利確シミュレーター（国保税込み）")
    ap.add_argument("--biz",    type=int, default=0, help="事業所得（赤字はマイナス）")
    ap.add_argument("--re",     type=int, default=0, help="不動産所得（赤字はマイナス）")
    ap.add_argument("--other",  type=int, default=0, help="その他の総合課税の所得")
    ap.add_argument("--sep",    type=int, default=0, help="分離長期譲渡所得（不動産売却益）")
    ap.add_argument("--ded",    type=int, default=0, help="所得税の所得控除 合計")
    ap.add_argument("--ded-r",  type=int, default=None, help="住民税の所得控除 合計")
    ap.add_argument("--spouse", type=int, default=0, help="うち配偶者（特別）控除")
    ap.add_argument("--members",  type=int, default=1, help="世帯の国保加入者数")
    ap.add_argument("--kaigo",    type=int, default=0, help="うち40〜64歳")
    ap.add_argument("--children", type=int, default=0, help="うち18歳未満")
    ap.add_argument("--step", type=int, default=1_000_000, help="試算の刻み（円）")
    a = ap.parse_args(argv)

    p = Params(a.biz, a.re, a.other, a.sep, a.ded, a.ded_r, a.spouse,
               a.members, a.kaigo, a.children)
    cap = find_capacity(p)
    zero = simulate(p, 0)

    print("=" * 78)
    print(f" 税ゼロ吸収枠: {cap:,} 円")
    print(f"   ＝ 所得控除 {p.ded:,} −（事業 {p.biz:,} ＋ 不動産 {p.re:,} ＋ その他 {p.other:,}）")
    if p.sep:
        print(f"   ※分離長期譲渡所得 {p.sep:,} 円があるため、控除の食い合いを織り込んで再計算")
    print("=" * 78)
    if zero.kokuho or zero.resident_tax:
        print(f" ⚠ 所得税ゼロ＝負担ゼロではない。利確0円でも"
              f" 国保税 {zero.kokuho:,} 円 ／ 住民税 {zero.resident_tax:,} 円")
    print()

    marks = sorted({0, cap} | {a.step * i for i in range(1, 13)})
    print(f"{'利確額':>12} {'所得税+復興':>12} {'住民税':>10} {'国保税':>10} "
          f"{'負担合計':>11} {'実効率':>7} {'手取り増':>12}")
    print("-" * 78)
    for g in marks:
        r = simulate(p, g)
        delta = r.total - zero.total
        rate = (delta / g * 100) if g else 0
        mark = " ←枠" if g == cap and cap else ""
        print(f"{g:>12,} {r.income_tax + r.reconstruction:>12,} {r.resident_tax:>10,} "
              f"{r.kokuho:>10,} {r.total:>11,} "
              f"{(f'{rate:.1f}%' if g else '—'):>7} {(f'{g - delta:,}' if g else '—'):>12}{mark}")
    print("-" * 78)
    print(" 実効率＝（利確0円のときと比べて増えた負担）÷ 利確額。国保税の増加を含む。")
    print(" 国保税は印西市 令和8年度の料率。年度が変わったら市の公表値を確認すること。")
    print(" この試算は概算。実際の申告・納付額は税務署・市役所の計算が優先する。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
