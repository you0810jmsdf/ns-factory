"""
tax_sim.py の単体テスト

ブラウザ版（監理幕僚室の暗号資産 計算書ツール）と同じ結果になることを担保する。
期待値はブラウザ版の実測値であり、どちらかを直したら必ず両方を合わせること。
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tax_sim import Params, simulate, find_capacity, income_tax_of  # noqa: E402


class IncomeTaxTest(unittest.TestCase):
    """所得税の速算表が境界で正しいこと。"""

    def test_brackets(self):
        cases = [
            (        0,         0),
            (1_950_000,    97_500),   # 5% の上限
            (1_950_001,    97_500),   # 千円未満切捨てで同額
            (1_951_000,    97_600),   # 10% 区分に入る
            (3_300_000,   232_500),
            (6_950_000,   962_500),
            (9_000_000, 1_434_000),
            (18_000_000, 4_404_000),
        ]
        for taxable, expected in cases:
            with self.subTest(taxable=taxable):
                self.assertEqual(income_tax_of(taxable), expected)

    def test_negative_is_zero(self):
        self.assertEqual(income_tax_of(-1_000_000), 0)


class CapacityTest(unittest.TestCase):
    """税ゼロ吸収枠が理論値と一致すること。"""

    def test_matches_hand_calculation(self):
        # 吸収枠 = 所得控除 −（事業 ＋ 不動産）
        #        = 2,000,000 −（−1,200,000 − 400,000）= 3,600,000
        p = Params(biz=-1_200_000, re=-400_000, ded=2_000_000, spouse=380_000,
                   members=1, kaigo=1)
        self.assertEqual(find_capacity(p), 3_600_000)

    def test_separate_gain_eats_the_capacity(self):
        """分離長期譲渡所得があると控除を食い合い、吸収枠が縮む。"""
        base = Params(biz=-1_200_000, re=-400_000, ded=2_000_000, spouse=380_000,
                      members=1, kaigo=1)
        with_sale = Params(biz=-1_200_000, re=-400_000, sep=3_400_000,
                           ded=2_000_000, spouse=380_000, members=1, kaigo=1)
        self.assertEqual(find_capacity(base), 3_600_000)
        self.assertLess(find_capacity(with_sale), find_capacity(base))
        # 譲渡益3,400,000が枠を食うので、残りは 3,600,000 − 3,400,000 = 200,000
        self.assertEqual(find_capacity(with_sale), 200_000)

    def test_no_room_when_already_taxable(self):
        p = Params(other=10_000_000, ded=500_000, members=1)
        self.assertEqual(find_capacity(p), 0)


class SimulateTest(unittest.TestCase):
    """試算がブラウザ版と一致すること。"""

    def setUp(self):
        self.p = Params(biz=-1_200_000, re=-400_000, ded=2_000_000,
                        spouse=380_000, members=1, kaigo=1)

    def test_zero_gain_still_costs_kokuho(self):
        """所得税ゼロ＝負担ゼロではない。均等割は所得に関係なく発生する。"""
        r = simulate(self.p, 0)
        self.assertEqual(r.income_tax, 0)
        # 均等割のみ: 医療24,000+平等割29,000 / 支援11,500 / 介護14,000 / 子育て1,730
        self.assertEqual(r.kokuho, 24_000 + 29_000 + 11_500 + 14_000 + 1_730)

    def test_within_capacity_no_income_tax(self):
        self.assertEqual(simulate(self.p, 3_600_000).income_tax, 0)

    def test_just_over_capacity_has_income_tax(self):
        self.assertGreater(simulate(self.p, 3_700_000).income_tax, 0)

    def test_business_loss_absorbs_gain(self):
        """赤字1,600,000の範囲の利確なら総所得はゼロのまま＝国保も増えない。"""
        a = simulate(self.p, 0)
        b = simulate(self.p, 1_500_000)
        self.assertEqual(b.total_income, 0)
        self.assertEqual(a.kokuho, b.kokuho)

    def test_kokuho_hits_the_cap(self):
        """賦課限度額113万円で頭打ちになること。"""
        r = simulate(self.p, 50_000_000)
        self.assertEqual(r.kokuho, 670_000 + 260_000 + 170_000 + 30_000)
        self.assertEqual(r.kokuho, 1_130_000)

    def test_spouse_deduction_disappears_over_10m(self):
        """合計所得1,000万円超で配偶者控除が消え、税の増え方が跳ねること。"""
        low = simulate(self.p, 11_000_000)     # 合計所得 9,400,000（控除は26万に逓減済み）
        high = simulate(self.p, 12_000_000)    # 合計所得 10,400,000（控除は消滅）
        self.assertLessEqual(low.total_income, 10_000_000)
        self.assertGreater(high.total_income, 10_000_000)

        # どちらも所得税は23%区分。控除消滅がなければ 1,000,000×23% = 230,000 の増加で済む。
        # 実際は残っていた配偶者控除260,000も課税対象になるため、その分だけ余計に増える。
        plain = int(1_000_000 * 0.23)
        actual = high.income_tax - low.income_tax
        self.assertGreater(actual, plain)
        self.assertAlmostEqual(actual, int((1_000_000 + 260_000) * 0.23), delta=200)

    def test_spouse_deduction_steps(self):
        """配偶者控除の逓減が 38万 → 26万 → 13万 → 0 と段階的に効くこと。"""
        from tax_sim import spouse_cap_of
        for total, expected in [(8_000_000, 380_000), (9_400_000, 260_000),
                                (9_800_000, 130_000), (10_500_000, 0)]:
            with self.subTest(total=total):
                self.assertEqual(spouse_cap_of(total, 380_000, False), expected)


if __name__ == "__main__":
    unittest.main()
