# -*- coding: utf-8 -*-
"""総平均法計算エンジンの単体テスト。"""

from __future__ import annotations

import unittest
from decimal import Decimal

from calc import MarginResult, OpeningBalance, Trade, calculate, total_income


class CalculateTest(unittest.TestCase):
    """国税庁計算書と同じ集計式になることを確認する。"""

    def assert_decimal_close(
        self,
        actual: Decimal,
        expected: Decimal,
        places: int = 6,
    ) -> None:
        """Decimal 同士を指定小数桁の許容差で比較する。"""

        tolerance = Decimal(1).scaleb(-places)
        self.assertLessEqual(abs(actual - expected), tolerance)

    def test_okj_btc_reiwa7_values(self) -> None:
        """検証用の架空値を再現する。"""

        results = calculate(
            trades=[
                Trade(
                    date="2025-01-15",
                    currency="BTC",
                    kind="buy",
                    quantity=Decimal("0.87654321"),
                    amount_jpy=Decimal("7654321.09"),
                ),
                Trade(
                    date="2025-06-15",
                    currency="BTC",
                    kind="sell",
                    quantity=Decimal("0.55555555"),
                    amount_jpy=Decimal("6000000"),
                    fee_jpy=Decimal("1234.56"),
                ),
            ],
            openings=[
                OpeningBalance(
                    currency="BTC",
                    quantity=Decimal("1.23456789"),
                    amount_jpy=Decimal("9876543.21"),
                )
            ],
        )

        result = results["BTC"]
        self.assertEqual(result.A, Decimal("1.23456789"))
        self.assertEqual(result.B, Decimal("9876543.21"))
        self.assertEqual(result.C, Decimal("0.87654321"))
        self.assertEqual(result.D, Decimal("7654321.09"))
        self.assert_decimal_close(result.E, Decimal("8304093.659495229"))
        self.assertEqual(result.F, Decimal("0.55555555"))
        self.assert_decimal_close(result.G, Decimal("4613385.320252385"))
        self.assertEqual(result.H, Decimal("1.55555555"))
        self.assert_decimal_close(result.I, Decimal("12917478.979747614"))
        self.assertEqual(result.income_jpy, Decimal("6000000"))
        self.assertEqual(result.sell_fee_jpy, Decimal("1234.56"))
        self.assertEqual(result.taxable_income_jpy, Decimal("1385380"))
        self.assertEqual(total_income(results), Decimal("1385380"))

    def test_zero_opening_buy_then_sell_all_leaves_zero_balance(self) -> None:
        """年始残高ゼロから購入し、全量売却すると年末残高もゼロになる。"""

        result = calculate(
            trades=[
                Trade(
                    date="2025-02-01",
                    currency="BTC",
                    kind="buy",
                    quantity=Decimal("2"),
                    amount_jpy=Decimal("10000"),
                ),
                Trade(
                    date="2025-03-01",
                    currency="BTC",
                    kind="sell",
                    quantity=Decimal("2"),
                    amount_jpy=Decimal("12000"),
                ),
            ],
            openings=[
                OpeningBalance(
                    currency="BTC",
                    quantity=Decimal("0"),
                    amount_jpy=Decimal("0"),
                )
            ],
        )["BTC"]

        self.assertEqual(result.E, Decimal("5000"))
        self.assertEqual(result.G, Decimal("10000"))
        self.assertEqual(result.H, Decimal("0"))
        self.assertEqual(result.I, Decimal("0"))
        self.assertEqual(result.taxable_income_jpy, Decimal("2000"))

    def test_sell_more_than_holding_raises_value_error(self) -> None:
        """保有数量を超える売却は年末残高数量が負になるためエラーにする。"""

        with self.assertRaises(ValueError):
            calculate(
                trades=[
                    Trade(
                        date="2025-04-01",
                        currency="ETH",
                        kind="sell",
                        quantity=Decimal("1"),
                        amount_jpy=Decimal("300000"),
                    )
                ],
                openings=[],
            )

    def test_margin_profit_and_loss_are_added(self) -> None:
        """証拠金取引の差益は収入、差損は必要経費に加算する。"""

        result = calculate(
            trades=[],
            openings=[],
            margins=[
                MarginResult(
                    currency="BTC",
                    profit_jpy=Decimal("5000.75"),
                    loss_jpy=Decimal("1500.25"),
                )
            ],
        )["BTC"]

        self.assertEqual(result.income_jpy, Decimal("5000.75"))
        self.assertEqual(result.expenses_jpy, Decimal("1500.25"))
        self.assertEqual(result.taxable_income_jpy, Decimal("3500"))

    def test_multiple_currencies_are_calculated_independently(self) -> None:
        """複数通貨を同時に渡しても通貨別に独立して集計する。"""

        results = calculate(
            trades=[
                Trade(
                    date="2025-05-01",
                    currency="BTC",
                    kind="sell",
                    quantity=Decimal("0.4"),
                    amount_jpy=Decimal("80"),
                ),
                Trade(
                    date="2025-05-02",
                    currency="ETH",
                    kind="buy",
                    quantity=Decimal("5"),
                    amount_jpy=Decimal("150"),
                ),
                Trade(
                    date="2025-05-03",
                    currency="ETH",
                    kind="sell",
                    quantity=Decimal("3"),
                    amount_jpy=Decimal("120"),
                ),
            ],
            openings=[
                OpeningBalance(
                    currency="BTC",
                    quantity=Decimal("1"),
                    amount_jpy=Decimal("100"),
                ),
                OpeningBalance(
                    currency="ETH",
                    quantity=Decimal("10"),
                    amount_jpy=Decimal("300"),
                ),
            ],
        )

        btc = results["BTC"]
        eth = results["ETH"]
        self.assertEqual(btc.E, Decimal("100"))
        self.assertEqual(btc.G, Decimal("40.0"))
        self.assertEqual(btc.H, Decimal("0.6"))
        self.assertEqual(btc.I, Decimal("60.0"))
        self.assertEqual(btc.taxable_income_jpy, Decimal("40"))

        self.assertEqual(eth.G, Decimal("90"))
        self.assertEqual(eth.H, Decimal("12"))
        self.assertEqual(eth.I, Decimal("360"))
        self.assertEqual(eth.taxable_income_jpy, Decimal("30"))

    def test_duplicate_opening_balance_raises_value_error(self) -> None:
        """同一通貨に年始残高が複数ある場合はエラーにする。"""

        with self.assertRaises(ValueError):
            calculate(
                trades=[],
                openings=[
                    OpeningBalance("BTC", Decimal("1"), Decimal("100")),
                    OpeningBalance("BTC", Decimal("2"), Decimal("200")),
                ],
            )


if __name__ == "__main__":
    unittest.main()