# -*- coding: utf-8 -*-
"""国税庁「暗号資産の計算書（総平均法用）」に合わせた計算エンジン。"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date as Date
from decimal import Decimal, ROUND_DOWN, localcontext


ZERO = Decimal("0")
YEN = Decimal("1")
CALC_PRECISION = 50
VALID_KINDS = {"buy", "sell"}


@dataclass(frozen=True, slots=True)
class Trade:
    """暗号資産の購入・売却明細。金額と数量は必ず Decimal で渡す。"""

    date: str
    currency: str
    kind: str
    quantity: Decimal
    amount_jpy: Decimal
    fee_jpy: Decimal = ZERO
    source: str = ""


@dataclass(frozen=True, slots=True)
class OpeningBalance:
    """年始時点の暗号資産残高。数量と金額は 0 以上の Decimal とする。"""

    currency: str
    quantity: Decimal
    amount_jpy: Decimal


@dataclass(frozen=True, slots=True)
class MarginResult:
    """証拠金取引の差益・差損。差損は負数ではなく正の金額で保持する。"""

    currency: str
    profit_jpy: Decimal
    loss_jpy: Decimal


@dataclass(frozen=True, slots=True)
class CurrencyResult:
    """通貨別の計算結果。A〜I は国税庁計算書の欄記号に対応する。"""

    currency: str
    A: Decimal  # 年始残高数量
    B: Decimal  # 年始残高金額
    C: Decimal  # 購入等数量
    D: Decimal  # 購入等金額
    E: Decimal  # 総平均単価
    F: Decimal  # 売却数量
    G: Decimal  # 売却原価
    H: Decimal  # 年末残高数量
    I: Decimal  # 年末残高金額
    income_jpy: Decimal  # 収入金額
    expenses_jpy: Decimal  # 必要経費
    taxable_income_jpy: Decimal  # 所得金額（1 円未満切捨て後）
    sell_fee_jpy: Decimal  # 売却時の手数料等合計


def calculate(
    trades: list[Trade],
    openings: list[OpeningBalance],
    margins: list[MarginResult] | None = None,
) -> dict[str, CurrencyResult]:
    """総平均法で通貨ごとの所得金額を計算する。"""

    margins = margins or []
    opening_by_currency = _collect_openings(openings)
    trades_by_currency = _group_trades(trades)
    margins_by_currency = _group_margins(margins)
    currencies = (
        set(opening_by_currency)
        | set(trades_by_currency)
        | set(margins_by_currency)
    )

    results: dict[str, CurrencyResult] = {}
    with localcontext() as ctx:
        ctx.prec = max(ctx.prec, CALC_PRECISION)
        for currency in sorted(currencies):
            opening = opening_by_currency.get(currency)
            currency_trades = trades_by_currency.get(currency, [])
            currency_margins = margins_by_currency.get(currency, [])

            A = opening.quantity if opening else ZERO
            B = opening.amount_jpy if opening else ZERO
            C = sum(
                (trade.quantity for trade in currency_trades if trade.kind == "buy"),
                ZERO,
            )
            D = sum(
                (trade.amount_jpy for trade in currency_trades if trade.kind == "buy"),
                ZERO,
            )
            purchase_base_quantity = A + C
            E = ZERO if purchase_base_quantity == ZERO else (B + D) / purchase_base_quantity
            F = sum(
                (trade.quantity for trade in currency_trades if trade.kind == "sell"),
                ZERO,
            )
            G = E * F
            H = A + C - F
            if H < ZERO:
                raise ValueError(f"{currency}: 年末残高数量が負になります")
            I = (B + D) - G

            sell_amount_jpy = sum(
                (trade.amount_jpy for trade in currency_trades if trade.kind == "sell"),
                ZERO,
            )
            sell_fee_jpy = sum(
                (trade.fee_jpy for trade in currency_trades if trade.kind == "sell"),
                ZERO,
            )
            margin_profit_jpy = sum(
                (margin.profit_jpy for margin in currency_margins),
                ZERO,
            )
            margin_loss_jpy = sum(
                (margin.loss_jpy for margin in currency_margins),
                ZERO,
            )

            income_jpy = sell_amount_jpy + margin_profit_jpy
            expenses_jpy = G + sell_fee_jpy + margin_loss_jpy
            taxable_income_jpy = (income_jpy - expenses_jpy).quantize(
                YEN,
                rounding=ROUND_DOWN,
            )

            results[currency] = CurrencyResult(
                currency=currency,
                A=A,
                B=B,
                C=C,
                D=D,
                E=E,
                F=F,
                G=G,
                H=H,
                I=I,
                income_jpy=income_jpy,
                expenses_jpy=expenses_jpy,
                taxable_income_jpy=taxable_income_jpy,
                sell_fee_jpy=sell_fee_jpy,
            )

    return results


def total_income(results: dict[str, CurrencyResult]) -> Decimal:
    """全通貨の所得金額を合計する。"""

    return sum((result.taxable_income_jpy for result in results.values()), ZERO)


def _collect_openings(openings: list[OpeningBalance]) -> dict[str, OpeningBalance]:
    """年始残高を通貨別に検証し、重複を検出する。"""

    opening_by_currency: dict[str, OpeningBalance] = {}
    for opening in openings:
        _validate_currency(opening.currency)
        _require_decimal(opening.quantity, "OpeningBalance.quantity")
        _require_decimal(opening.amount_jpy, "OpeningBalance.amount_jpy")
        _require_non_negative(opening.quantity, "OpeningBalance.quantity")
        _require_non_negative(opening.amount_jpy, "OpeningBalance.amount_jpy")
        if opening.currency in opening_by_currency:
            raise ValueError(f"{opening.currency}: OpeningBalance が複数あります")
        opening_by_currency[opening.currency] = opening
    return opening_by_currency


def _group_trades(trades: list[Trade]) -> dict[str, list[Trade]]:
    """取引明細を通貨別に検証してまとめる。"""

    grouped: dict[str, list[Trade]] = defaultdict(list)
    for trade in trades:
        _validate_trade(trade)
        grouped[trade.currency].append(trade)
    return dict(grouped)


def _group_margins(margins: list[MarginResult]) -> dict[str, list[MarginResult]]:
    """証拠金取引の結果を通貨別に検証してまとめる。"""

    grouped: dict[str, list[MarginResult]] = defaultdict(list)
    for margin in margins:
        _validate_currency(margin.currency)
        _require_decimal(margin.profit_jpy, "MarginResult.profit_jpy")
        _require_decimal(margin.loss_jpy, "MarginResult.loss_jpy")
        _require_non_negative(margin.profit_jpy, "MarginResult.profit_jpy")
        _require_non_negative(margin.loss_jpy, "MarginResult.loss_jpy")
        grouped[margin.currency].append(margin)
    return dict(grouped)


def _validate_trade(trade: Trade) -> None:
    """1 件の取引明細が計算可能な形式か確認する。"""

    _validate_date(trade.date)
    _validate_currency(trade.currency)
    if trade.kind not in VALID_KINDS:
        raise ValueError(f"kind は {sorted(VALID_KINDS)} のいずれかです")
    _require_decimal(trade.quantity, "Trade.quantity")
    _require_decimal(trade.amount_jpy, "Trade.amount_jpy")
    _require_decimal(trade.fee_jpy, "Trade.fee_jpy")
    _require_positive(trade.quantity, "Trade.quantity")
    # 金額は 0 を許容する。エアドロップ・ステーキング報酬などの無償取得（取得価額0）、
    # および無償譲渡・出庫（売却価額0）が実在するため。
    # ※無償取得は本来「取得時の時価」が雑所得になる。0 のまま計上すると課税が
    #   売却時まで繰り延がる点に注意（report 側で警告として表示している）。
    _require_non_negative(trade.amount_jpy, "Trade.amount_jpy")
    _require_non_negative(trade.fee_jpy, "Trade.fee_jpy")


def _validate_date(value: str) -> None:
    """日付文字列が YYYY-MM-DD 形式か確認する。"""

    if not isinstance(value, str):
        raise TypeError("date は str である必要があります")
    if len(value) != 10 or value[4] != "-" or value[7] != "-":
        raise ValueError("date は YYYY-MM-DD 形式である必要があります")
    try:
        Date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("date は有効な日付である必要があります") from exc


def _validate_currency(value: str) -> None:
    """通貨コードが空でない文字列か確認する。"""

    if not isinstance(value, str):
        raise TypeError("currency は str である必要があります")
    if not value:
        raise ValueError("currency は空にできません")


def _require_decimal(value: Decimal, field_name: str) -> None:
    """float 混入を避けるため Decimal 型だけを受け付ける。"""

    if not isinstance(value, Decimal):
        raise TypeError(f"{field_name} は Decimal である必要があります")


def _require_positive(value: Decimal, field_name: str) -> None:
    """正の Decimal であることを確認する。"""

    if value <= ZERO:
        raise ValueError(f"{field_name} は正の数である必要があります")


def _require_non_negative(value: Decimal, field_name: str) -> None:
    """0 以上の Decimal であることを確認する。"""

    if value < ZERO:
        raise ValueError(f"{field_name} は 0 以上である必要があります")


__all__ = [
    "Trade",
    "OpeningBalance",
    "MarginResult",
    "CurrencyResult",
    "calculate",
    "total_income",
]