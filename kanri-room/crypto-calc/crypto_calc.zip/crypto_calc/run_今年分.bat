@echo off
chcp 65001 > nul
cd /d "%~dp0"
for /f %%y in ('powershell -NoProfile -Command "(Get-Date).Year"') do set YR=%%y
echo.
echo === 当年分（%YR%年）を計算します ===
echo.
py crypto_calc.py --year %YR% %*
echo.
if errorlevel 1 (
  echo *** エラーが発生しました。上の内容を確認してください。 ***
) else (
  echo 出力先: %~dp0output
  start "" "%~dp0output"
)
echo.
pause